<?php
// /config/database.php

// On charge d'abord les constantes (pour avoir les chemins si besoin)
require_once __DIR__ . '/constants.php';

// --- PARAMÈTRES DE CONNEXION ---
$host = 'localhost';
$dbname = 'bukavu_traiteur';   // Nom de ta base de données
$username = 'root';            // Par défaut sur XAMPP/WAMP
$password = '';                // Par défaut vide sur XAMPP

// --- DÉMARRAGE DE LA SESSION (si ce n'est pas déjà fait) ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- CONNEXION PDO AVEC GESTION DES ERREURS ---
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // Active le mode exception pour que les erreurs SQL s'affichent pendant le dev
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Retourne les résultats sous forme de tableau associatif (colonnes nommées)
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Évite les problèmes de conversion des booléens en MySQL
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

} catch (PDOException $e) {
    // En production, affiche un message générique et log l'erreur
    // En développement, on peut afficher le message d'erreur
    die("❌ Erreur de connexion à la base de données : " . $e->getMessage());
}

// Optionnel : on stocke la connexion dans une constante pour l'utiliser partout
// Mais on utilisera simplement la variable $pdo
?>