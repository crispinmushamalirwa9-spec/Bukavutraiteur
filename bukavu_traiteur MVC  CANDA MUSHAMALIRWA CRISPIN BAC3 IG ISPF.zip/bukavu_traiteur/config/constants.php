<?php
// /config/constants.php

// --- Chemin racine du projet (absolu) ---
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', realpath(__DIR__ . '/../'));
}

// --- URL du site (À MODIFIER selon ton environnement) ---
// ⚠️ Remplace par l'URL de la racine de ton projet, avec le slash final.
if (!defined('SITE_URL')) {
    // En local avec WAMP, par exemple :
    define('SITE_URL', 'http://localhost/bukavutraiteur/');
    // En ligne, remplace par : define('SITE_URL', 'https://mondomaine.com/');
}

// --- Informations générales ---
define('SITE_NAME', 'BukavuTraiteur');
define('SITE_DESCRIPTION', 'La plateforme des traiteurs de Bukavu');

// --- Chemins d'upload (absolus) ---
define('UPLOAD_PATH', ROOT_PATH . '/assets/uploads/');
define('PROFILE_PICS_PATH', UPLOAD_PATH . 'profiles/');
define('POSTS_PATH', UPLOAD_PATH . 'posts/');

// --- URLs publiques des dossiers d'upload ---
define('UPLOAD_URL', SITE_URL . 'assets/uploads/');
define('PROFILE_PICS_URL', UPLOAD_URL . 'profiles/');
define('POSTS_URL', UPLOAD_URL . 'posts/');

// --- Limites d'upload ---
define('MAX_FILE_SIZE', 10 * 1024 * 1024);
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp']);
define('ALLOWED_VIDEO_TYPES', ['video/mp4', 'video/webm', 'video/avi', 'video/quicktime']);

// --- Règles métier ---
define('REPORT_LIMIT_BEFORE_DELETE', 2);
define('ADMIN_CREATION_TOKEN', 'SuperSecretTokenBukavu2026!');

// --- Fuseau horaire ---
date_default_timezone_set('Africa/Lubumbashi');
?>