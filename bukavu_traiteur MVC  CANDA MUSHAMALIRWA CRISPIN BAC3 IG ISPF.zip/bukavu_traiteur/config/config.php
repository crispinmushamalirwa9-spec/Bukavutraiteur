<?php
// /config/config.php

// On ne définit pas ROOT_PATH ici, on laisse constants.php le faire.
// On inclut d'abord les constantes
require_once __DIR__ . '/constants.php';

// Puis la base de données
require_once __DIR__ . '/database.php';

// Puis les fonctions métier
require_once ROOT_PATH . '/includes/functions.php';

// --- Fonctions techniques (déjà présentes) ---
function check_role($required_role) {
    if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== $required_role) {
        header('Location: /' . $required_role . '/login.php');
        exit;
    }
}
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
function redirect_with_message($url, $message, $type = 'success') {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
    header("Location: $url");
    exit;
}
function display_flash_message() {
    if (isset($_SESSION['flash_message'])) {
        $type = $_SESSION['flash_type'] ?? 'info';
        $message = $_SESSION['flash_message'];
        echo '<div class="flash-message flash-' . $type . '">' . e($message) . '</div>';
        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
    }
}
?>