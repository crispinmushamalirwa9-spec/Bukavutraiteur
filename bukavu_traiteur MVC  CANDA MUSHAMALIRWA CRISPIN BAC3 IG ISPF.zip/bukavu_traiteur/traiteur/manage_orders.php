<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'traiteur') {
    header('Location: login.php');
    exit;
}

// Récupérer le nom du service pour le header
$stmt = $pdo->prepare("SELECT service_name FROM traiteur_profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

// --- TRAITEMENT DES ACTIONS ---
$msg = '';
$error = '';

if (isset($_GET['action']) && isset($_GET['id'])) {
    $order_id = (int)$_GET['id'];
    $action = $_GET['action'];
    $new_status = '';

    if ($action === 'accept') $new_status = 'en_cours';
    elseif ($action === 'complete') $new_status = 'termine';
    elseif ($action === 'refuse') $new_status = 'refuse';

    if ($new_status) {
        // Vérifier que la commande appartient bien à ce traiteur
        $check = $pdo->prepare("SELECT client_id FROM orders WHERE id = ? AND traiteur_id = ?");
        $check->execute([$order_id, $user_id]);
        if ($check->rowCount() > 0) {
            $client_id = $check->fetchColumn();
            $update = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
            $update->execute([$new_status, $order_id]);

            // Notifier le client
            $status_labels = [
                'en_cours' => 'acceptée et en cours de préparation',
                'termine' => 'terminée',
                'refuse' => 'refusée'
            ];
            $label = $status_labels[$new_status] ?? $new_status;
            add_notification($pdo, $client_id, "Votre commande #$order_id a été $label par le traiteur.");

            // Si refus, notifier l'admin
            if ($new_status === 'refuse') {
                add_notification($pdo, 1, "Commande #$order_id refusée par le traiteur ID $user_id.");
            }

            // Redirection avec message
            $_SESSION['flash_message'] = "✅ Commande mise à jour : $new_status";
            $_SESSION['flash_type'] = 'success';
            header('Location: manage_orders.php');
            exit;
        } else {
            $error = "Vous n'avez pas le droit de modifier cette commande.";
        }
    }
}

// Afficher les messages flash
if (isset($_SESSION['flash_message'])) {
    $msg = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
    unset($_SESSION['flash_type']);
}

// Récupérer toutes les commandes du traiteur
$stmt = $pdo->prepare("
    SELECT o.*, cp.full_name as client_name, cp.phone as client_phone, st.name as service_name
    FROM orders o
    JOIN client_profiles cp ON o.client_id = cp.user_id
    LEFT JOIN service_types st ON o.service_type_id = st.id
    WHERE o.traiteur_id = ?
    ORDER BY FIELD(o.status, 'en_attente', 'en_cours', 'termine', 'refuse'), o.created_at DESC
");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer les commandes - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }
        .alert {
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        .alert-success {
            background: rgba(46, 125, 50, 0.2);
            border-color: #2e7d32;
            color: #a5d6a7;
        }
        .alert-danger {
            background: rgba(244, 67, 54, 0.2);
            border-color: #f44336;
            color: #ffcdd2;
        }

        .table-wrap {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }
        th {
            text-align: left;
            padding: 12px 12px;
            color: rgba(255,255,255,0.7);
            font-weight: 600;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        td {
            padding: 12px 12px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            vertical-align: middle;
        }
        .badge {
            display: inline-block;
            padding: 3px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-warning { background: rgba(255, 193, 7, 0.3); color: #ffe082; }
        .badge-info { background: rgba(33, 150, 243, 0.3); color: #90caf9; }
        .badge-success { background: rgba(46, 125, 50, 0.3); color: #a5d6a7; }
        .badge-danger { background: rgba(244, 67, 54, 0.3); color: #ffcdd2; }

        .btn-action {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.8rem;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            margin: 2px;
            text-decoration: none;
        }
        .btn-accept { background: rgba(46, 125, 50, 0.3); color: #a5d6a7; }
        .btn-accept:hover { background: #2e7d32; color: #fff; }
        .btn-complete { background: rgba(33, 150, 243, 0.3); color: #90caf9; }
        .btn-complete:hover { background: #0d47a1; color: #fff; }
        .btn-refuse { background: rgba(244, 67, 54, 0.3); color: #ffcdd2; }
        .btn-refuse:hover { background: #c62828; color: #fff; }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
            table { font-size: 0.85rem; }
            .btn-action { padding: 2px 8px; font-size: 0.7rem; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="../index.php"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="create_post.php">Publier</a></li>
                <li><a href="manage_orders.php">Commandes</a></li>
                <li><a href="ranking.php">Classement</a></li>
                <li><a href="report_client.php">Signaler</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-utensil-spoon"></i> <?= htmlspecialchars($profile['service_name'] ?? 'Traiteur') ?>
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <div class="section">
            <h2><i class="fas fa-clipboard-list"></i> Gestion des commandes</h2>

            <?php if ($msg): ?>
                <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Client</th>
                            <th>Service</th>
                            <th>Date cérémonie</th>
                            <th>Description</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($orders)): ?>
                            <tr><td colspan="7" style="text-align:center; color:rgba(255,255,255,0.4); padding:30px;">Aucune commande reçue.</td></tr>
                        <?php else: ?>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><strong>#<?= $order['id'] ?></strong></td>
                                    <td>
                                        <?= htmlspecialchars($order['client_name']) ?><br>
                                        <small style="color:rgba(255,255,255,0.5);"><?= htmlspecialchars($order['client_phone']) ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($order['service_name'] ?? 'Non précisé') ?></td>
                                    <td><?= date('d/m/Y', strtotime($order['ceremony_date'])) ?></td>
                                    <td><?= htmlspecialchars(substr($order['description'], 0, 30)) . (strlen($order['description']) > 30 ? '...' : '') ?></td>
                                    <td>
                                        <span class="badge badge-<?= $order['status'] === 'en_attente' ? 'warning' : ($order['status'] === 'en_cours' ? 'info' : ($order['status'] === 'termine' ? 'success' : 'danger')) ?>">
                                            <?= $order['status'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($order['status'] === 'en_attente'): ?>
                                            <a href="?action=accept&id=<?= $order['id'] ?>" class="btn-action btn-accept" onclick="return confirm('Accepter cette commande ?')">
                                                <i class="fas fa-check"></i> Accepter
                                            </a>
                                            <a href="?action=refuse&id=<?= $order['id'] ?>" class="btn-action btn-refuse" onclick="return confirm('Refuser cette commande ?')">
                                                <i class="fas fa-times"></i> Refuser
                                            </a>
                                        <?php elseif ($order['status'] === 'en_cours'): ?>
                                            <a href="?action=complete&id=<?= $order['id'] ?>" class="btn-action btn-complete" onclick="return confirm('Marquer comme terminée ?')">
                                                <i class="fas fa-check-double"></i> Terminer
                                            </a>
                                        <?php else: ?>
                                            <span style="color:rgba(255,255,255,0.3);">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

<script>
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>