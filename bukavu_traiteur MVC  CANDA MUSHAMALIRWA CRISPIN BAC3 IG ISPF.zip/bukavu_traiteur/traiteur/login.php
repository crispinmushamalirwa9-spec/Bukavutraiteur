<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if ($user_id && $user_role === 'traiteur') {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Veuillez saisir votre email et votre mot de passe.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'traiteur'");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            // Vérification avec password_hash
            if ($user && password_verify($password, $user['password_hash'])) {
                if ($user['status'] === 'actif') {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_role'] = $user['role'];
                    $_SESSION['user_email'] = $user['email'];
                    header('Location: dashboard.php');
                    exit;
                } else {
                    $error = 'Votre compte est désactivé. Contactez l\'administrateur.';
                }
            } else {
                $error = 'Email ou mot de passe incorrect.';
            }
        } catch (PDOException $e) {
            $error = 'Erreur technique : ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion Traiteur - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #0f0f0f;
            color: #fff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background-image: url('../assets/images/justine.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-blend-mode: overlay;
            background-color: rgba(0,0,0,0.6);
        }
        .login-container {
            background: rgba(0, 0, 0, 0.55);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            padding: 40px 35px;
            border-radius: 28px;
            max-width: 420px;
            width: 90%;
            box-shadow: 0 20px 50px rgba(0,0,0,0.6);
            border: 1px solid rgba(255,255,255,0.08);
            text-align: center;
            margin: 20px;
        }
        .login-container .icon {
            font-size: 3rem;
            color: #a5d6a7;
            margin-bottom: 10px;
        }
        .login-container h1 {
            font-size: 1.8rem;
            font-weight: 800;
            margin-bottom: 6px;
        }
        .login-container .sub {
            color: rgba(255,255,255,0.6);
            font-weight: 300;
            margin-bottom: 25px;
        }
        .login-container .error {
            background: rgba(244, 67, 54, 0.15);
            border-left: 4px solid #f44336;
            padding: 12px 16px;
            border-radius: 12px;
            color: #ffcdd2;
            font-size: 0.95rem;
            margin-bottom: 20px;
            text-align: left;
        }
        .login-container label {
            display: block;
            font-weight: 600;
            font-size: 0.9rem;
            text-align: left;
            margin: 12px 0 4px;
            color: rgba(255,255,255,0.8);
        }
        .login-container input {
            width: 100%;
            padding: 12px 16px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            color: #fff;
            font-size: 1rem;
            transition: 0.3s;
        }
        .login-container input:focus {
            outline: none;
            border-color: #a5d6a7;
            background: rgba(255,255,255,0.12);
            box-shadow: 0 0 0 4px rgba(46, 125, 50, 0.15);
        }
        .login-container input::placeholder {
            color: rgba(255,255,255,0.3);
        }
        .login-container button {
            width: 100%;
            padding: 14px;
            margin-top: 20px;
            background: #2e7d32;
            border: none;
            border-radius: 60px;
            color: #fff;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            transition: 0.3s;
            box-shadow: 0 8px 25px rgba(46, 125, 50, 0.35);
        }
        .login-container button:hover {
            background: #1a3c2a;
            transform: translateY(-2px);
        }
        .login-container .links {
            margin-top: 20px;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.5);
        }
        .login-container .links a {
            color: #a5d6a7;
            font-weight: 600;
            text-decoration: none;
        }
        .login-container .links a:hover {
            text-decoration: underline;
        }
        .footer-note {
            margin-top: 30px;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.3);
            text-align: center;
        }
        @media (max-width: 480px) {
            .login-container { padding: 30px 20px; }
        }
    </style>
</head>
<body>

    <div class="login-container">
        <div class="icon"><i class="fas fa-utensils"></i></div>
        <h1>Espace Traiteur</h1>
        <p class="sub">Connectez-vous à votre espace professionnel</p>

        <?php if ($error): ?>
            <div class="error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="email">Email <span style="color:#ffcdd2;">*</span></label>
            <input type="email" id="email" name="email" placeholder="votre@email.com" required>

            <label for="password">Mot de passe <span style="color:#ffcdd2;">*</span></label>
            <input type="password" id="password" name="password" placeholder="••••••••" required>

            <button type="submit"><i class="fas fa-sign-in-alt"></i> Se connecter</button>
        </form>

        <div class="links">
            <p>Pas encore de compte ? <a href="register.php">Inscrivez-vous</a></p>
            <p><a href="../index.php"><i class="fas fa-arrow-left"></i> Retour à l'accueil</a></p>
        </div>
    </div>

    <div class="footer-note">
        &copy; <?= date('Y') ?> BukavuTraiteur – Tous droits réservés.
    </div>

</body>
</html>