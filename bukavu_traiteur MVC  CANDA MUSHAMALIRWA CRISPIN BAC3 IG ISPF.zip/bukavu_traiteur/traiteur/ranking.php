<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'traiteur') {
    header('Location: login.php');
    exit;
}

// Récupérer le nom du service pour le header
$stmt = $pdo->prepare("SELECT service_name FROM traiteur_profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

// Mettre à jour les scores avant d'afficher
update_all_rankings($pdo);

// Récupérer tous les traiteurs triés par score
$stmt = $pdo->query("
    SELECT tp.user_id, tp.service_name, tp.profile_pic, tp.ranking_score, tp.loyalty_score,
           (SELECT COUNT(*) FROM orders WHERE traiteur_id = tp.user_id AND status = 'termine') as total_done
    FROM traiteur_profiles tp
    JOIN users u ON tp.user_id = u.id
    WHERE u.status = 'actif'
    ORDER BY tp.ranking_score DESC
");
$traiteurs = $stmt->fetchAll();

// Trouver le rang du traiteur connecté
$my_rank = 0;
foreach ($traiteurs as $index => $t) {
    if ($t['user_id'] == $user_id) {
        $my_rank = $index + 1;
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classement - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }

        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }

        .my-rank-box {
            background: rgba(46, 125, 50, 0.15);
            border: 1px solid rgba(46, 125, 50, 0.3);
            border-radius: 16px;
            padding: 20px;
            text-align: center;
            margin-bottom: 30px;
        }
        .my-rank-box .rank-number {
            font-size: 3rem;
            font-weight: 900;
            color: #a5d6a7;
        }
        .my-rank-box .rank-label {
            color: rgba(255,255,255,0.6);
        }

        .ranking-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            transition: 0.2s;
        }
        .ranking-item:hover {
            background: rgba(255,255,255,0.03);
        }
        .ranking-item.highlight {
            background: rgba(46, 125, 50, 0.15);
            border-left: 4px solid #a5d6a7;
            border-radius: 0 12px 12px 0;
        }
        .ranking-item .rank-position {
            width: 50px;
            font-weight: 800;
            font-size: 1.2rem;
            color: rgba(255,255,255,0.4);
        }
        .ranking-item .rank-position.gold { color: #f9a825; }
        .ranking-item .rank-position.silver { color: #bdbdbd; }
        .ranking-item .rank-position.bronze { color: #e67e22; }

        .ranking-item img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            background: rgba(255,255,255,0.05);
            margin-right: 16px;
            border: 2px solid transparent;
        }
        .ranking-item.highlight img {
            border-color: #a5d6a7;
        }

        .ranking-item .info {
            flex: 1;
        }
        .ranking-item .info h4 {
            font-weight: 700;
            font-size: 1.1rem;
        }
        .ranking-item .info small {
            color: rgba(255,255,255,0.4);
            font-size: 0.85rem;
        }
        .ranking-item .score {
            font-weight: 700;
            color: #a5d6a7;
            text-align: right;
        }
        .ranking-item .score span {
            display: block;
            font-weight: 400;
            color: rgba(255,255,255,0.3);
            font-size: 0.7rem;
        }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
            .ranking-item { flex-wrap: wrap; }
            .ranking-item .score { width: 100%; text-align: left; margin-top: 4px; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="../index.php"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="create_post.php">Publier</a></li>
                <li><a href="manage_orders.php">Commandes</a></li>
                <li><a href="ranking.php">Classement</a></li>
                <li><a href="report_client.php">Signaler</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-utensil-spoon"></i> <?= htmlspecialchars($profile['service_name'] ?? 'Traiteur') ?>
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <div class="section">
            <h2><i class="fas fa-trophy"></i> Classement des traiteurs</h2>

            <!-- Ma position -->
            <div class="my-rank-box">
                <p style="color:rgba(255,255,255,0.6);">Votre position actuelle</p>
                <div class="rank-number">#<?= $my_rank ?: 'Non classé' ?></div>
                <p style="color:rgba(255,255,255,0.4); font-size:0.9rem;">
                    Parmi <?= count($traiteurs) ?> traiteurs actifs
                </p>
            </div>

            <!-- Liste des traiteurs -->
            <?php if (empty($traiteurs)): ?>
                <p style="text-align:center; color:rgba(255,255,255,0.4); padding:30px;">Aucun traiteur actif.</p>
            <?php else: ?>
                <?php foreach ($traiteurs as $index => $t): 
                    $rank = $index + 1;
                    $rank_class = '';
                    if ($rank === 1) $rank_class = 'gold';
                    elseif ($rank === 2) $rank_class = 'silver';
                    elseif ($rank === 3) $rank_class = 'bronze';
                    $is_me = ($t['user_id'] == $user_id);
                ?>
                    <div class="ranking-item <?= $is_me ? 'highlight' : '' ?>">
                        <div class="rank-position <?= $rank_class ?>">#<?= $rank ?></div>
                        <img src="<?= SITE_URL ?>assets/uploads/profiles/<?= htmlspecialchars($t['profile_pic'] ?? 'default_traiteur.jpg') ?>" alt="">
                        <div class="info">
                            <h4><?= htmlspecialchars($t['service_name']) ?> <?= $is_me ? '👈 (Vous)' : '' ?></h4>
                            <small><?= $t['total_done'] ?> commandes terminées</small>
                        </div>
                        <div class="score">
                            <?= number_format($t['ranking_score'], 2) ?>
                            <span>Score</span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

    </div>
</main>

<script>
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>