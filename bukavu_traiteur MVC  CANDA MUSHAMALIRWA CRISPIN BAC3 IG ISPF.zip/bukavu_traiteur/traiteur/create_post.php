<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'traiteur') {
    header('Location: login.php');
    exit;
}

// Récupérer le nom du service pour le header
$stmt = $pdo->prepare("SELECT service_name FROM traiteur_profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $caption = trim($_POST['caption'] ?? '');

    if (isset($_FILES['media']) && $_FILES['media']['error'] === UPLOAD_ERR_OK) {
        if (!is_dir(POSTS_PATH)) {
            mkdir(POSTS_PATH, 0777, true);
        }

        $upload_result = upload_file($_FILES['media'], POSTS_PATH);

        if ($upload_result['success']) {
            $stmt = $pdo->prepare("INSERT INTO posts (traiteur_id, media_path, caption) VALUES (?, ?, ?)");
            $inserted = $stmt->execute([$user_id, $upload_result['filename'], $caption]);

            if ($inserted) {
                $upd = $pdo->prepare("UPDATE traiteur_profiles SET total_posts = total_posts + 1 WHERE user_id = ?");
                $upd->execute([$user_id]);
                $success = '✅ Publication créée avec succès !';
            } else {
                $error = 'Erreur lors de l\'enregistrement en base de données.';
            }
        } else {
            $error = $upload_result['message'];
        }
    } else {
        $error = 'Veuillez sélectionner une photo ou une vidéo.';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publier - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }
        .alert {
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        .alert-success {
            background: rgba(46, 125, 50, 0.2);
            border-color: #2e7d32;
            color: #a5d6a7;
        }
        .alert-danger {
            background: rgba(244, 67, 54, 0.2);
            border-color: #f44336;
            color: #ffcdd2;
        }

        .form-group {
            margin-bottom: 18px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.8);
            margin-bottom: 4px;
        }
        .form-group input[type="file"] {
            width: 100%;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px dashed rgba(255,255,255,0.3);
            background: rgba(255,255,255,0.04);
            color: #fff;
            font-size: 1rem;
            transition: 0.3s;
            cursor: pointer;
        }
        .form-group input[type="file"]:hover {
            background: rgba(255,255,255,0.08);
        }
        .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            color: #fff;
            font-size: 1rem;
            transition: 0.3s;
            font-family: inherit;
            min-height: 100px;
            resize: vertical;
        }
        .form-group textarea:focus {
            outline: none;
            border-color: #a5d6a7;
            background: rgba(255,255,255,0.12);
            box-shadow: 0 0 0 4px rgba(46, 125, 50, 0.15);
        }
        .form-group textarea::placeholder {
            color: rgba(255,255,255,0.3);
        }
        .preview-box {
            margin-top: 10px;
            text-align: center;
            display: none;
        }
        .preview-box img, .preview-box video {
            max-width: 100%;
            max-height: 300px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.1);
        }

        .btn-submit {
            background: #2e7d32;
            color: #fff;
            border: none;
            padding: 14px 30px;
            border-radius: 60px;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            transition: 0.3s;
            width: 100%;
            box-shadow: 0 8px 25px rgba(46, 125, 50, 0.3);
        }
        .btn-submit:hover {
            background: #1a3c2a;
            transform: translateY(-2px);
        }
        .btn-submit:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .btn-explore {
            display: inline-block;
            background: rgba(255,255,255,0.1);
            color: #fff;
            border: 1px solid rgba(255,255,255,0.2);
            padding: 10px 24px;
            border-radius: 60px;
            font-weight: 600;
            font-size: 0.95rem;
            transition: 0.3s;
            text-align: center;
            margin-top: 15px;
            width: 100%;
            cursor: pointer;
        }
        .btn-explore:hover {
            background: rgba(255,255,255,0.2);
            transform: translateY(-2px);
        }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="../index.php"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="create_post.php">Publier</a></li>
                <li><a href="manage_orders.php">Commandes</a></li>
                <li><a href="ranking.php">Classement</a></li>
                <li><a href="report_client.php">Signaler</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-utensil-spoon"></i> <?= htmlspecialchars($profile['service_name'] ?? 'Traiteur') ?>
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <div class="section">
            <h2><i class="fas fa-plus-circle"></i> Nouvelle publication</h2>
            <p style="color:rgba(255,255,255,0.6); margin-bottom:20px;">Partagez vos plats, buffets ou vidéos de préparation.</p>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <?= $success ?> 
                    <a href="dashboard.php" style="color:#a5d6a7; font-weight:600;">Retour au dashboard</a>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <?php if (!$success): ?>
            <form method="POST" enctype="multipart/form-data" id="postForm">
                <div class="form-group">
                    <label>Photo ou vidéo <span style="color:#ffcdd2;">*</span> (JPEG, PNG, WEBP, MP4, max 10 Mo)</label>
                    <input type="file" name="media" accept="image/*,video/*" required onchange="previewMedia(this)">
                    <div class="preview-box" id="previewContainer">
                        <p style="color:rgba(255,255,255,0.4);">Aperçu</p>
                    </div>
                </div>

                <div class="form-group">
                    <label>Légende</label>
                    <textarea name="caption" placeholder="Décrivez votre plat, l'occasion, vos ingrédients..."></textarea>
                </div>

                <button type="submit" class="btn-submit" id="submitBtn">
                    <i class="fas fa-cloud-upload-alt"></i> Publier
                </button>
            </form>

            <!-- Lien vers view_posts -->
            <a href="view_posts.php" class="btn-explore">
                <i class="fas fa-images"></i> Voir les publications des autres traiteurs
            </a>

            <?php endif; ?>
        </div>

    </div>
</main>

<script>
    function previewMedia(input) {
        const container = document.getElementById('previewContainer');
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            const file = input.files[0];
            const isVideo = file.type.startsWith('video/');
            reader.onload = function(e) {
                let html = isVideo ?
                    `<video controls><source src="${e.target.result}" type="${file.type}"></video>` :
                    `<img src="${e.target.result}" alt="Aperçu">`;
                container.innerHTML = html;
                container.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            container.style.display = 'none';
        }
    }

    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>