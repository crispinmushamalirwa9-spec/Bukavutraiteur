<?php
// /traiteur/register.php
require_once __DIR__ . '/../config/config.php';

// Variables de session sécurisées
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;
$user_email = isset($_SESSION['user_email']) ? $_SESSION['user_email'] : null;

if ($user_id && $user_role === 'traiteur') {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $entered_code = trim($_POST['code']);

    if (empty($email) || empty($password) || empty($entered_code)) {
        $error = 'Tous les champs marqués * sont obligatoires.';
    } elseif ($password !== $confirm_password) {
        $error = 'Les mots de passe ne correspondent pas.';
    } elseif (strlen($password) < 6) {
        $error = 'Le mot de passe doit contenir au moins 6 caractères.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Adresse email invalide.';
    } else {
        $checkEmail = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $checkEmail->execute([$email]);
        if ($checkEmail->rowCount() > 0) {
            $error = 'Cet email est déjà utilisé. Veuillez vous connecter.';
        } else {
            $checkCode = $pdo->prepare("SELECT id FROM temp_codes WHERE code = ? AND is_used = 0");
            $checkCode->execute([$entered_code]);
            if ($checkCode->rowCount() === 0) {
                $error = '❌ Code invalide ou déjà utilisé. Contactez l\'administrateur.';
            } else {
                try {
                    $pdo->beginTransaction();
                    $password_hash = password_hash($password, PASSWORD_DEFAULT);
                    $insertUser = $pdo->prepare("INSERT INTO users (email, password_hash, role, status) VALUES (?, ?, 'traiteur', 'actif')");
                    $insertUser->execute([$email, $password_hash]);
                    $new_user_id = $pdo->lastInsertId();

                    $default_service_name = 'Traiteur_' . $new_user_id;
                    $default_address = 'À définir';
                    $default_description = '';

                    $insertProfile = $pdo->prepare("INSERT INTO traiteur_profiles (user_id, service_name, address, city, description) VALUES (?, ?, ?, 'Bukavu', ?)");
                    $insertProfile->execute([$new_user_id, $default_service_name, $default_address, $default_description]);

                    $updateCode = $pdo->prepare("UPDATE temp_codes SET is_used = 1 WHERE code = ?");
                    $updateCode->execute([$entered_code]);

                    $pdo->commit();
                    $success = '✅ Compte traiteur créé ! <a href="login.php" style="color:#a5d6a7; font-weight:700;">Connectez-vous</a> pour compléter votre profil.';
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $error = 'Une erreur technique est survenue. Veuillez réessayer.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription Traiteur - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            overflow-x: hidden;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        /* HEADER TRANSPARENT (inchangé) */
        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
            text-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .nav-menu li a.btn-primary {
            background: #2e7d32;
            color: #fff;
            box-shadow: 0 4px 15px rgba(46, 125, 50, 0.4);
        }
        .nav-menu li a.btn-primary:hover { background: #1a3c2a; transform: translateY(-2px); }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
            text-shadow: 0 2px 8px rgba(0,0,0,0.3);
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        /* SECTION PRINCIPALE – formulaire réduit */
        .main-content {
            flex: 1;
            padding: 120px 0 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-box {
            background: rgba(0,0,0,0.4);
            backdrop-filter: blur(12px);
            border-radius: 24px;
            padding: 28px 30px;
            max-width: 440px;        /* largeur réduite */
            width: 100%;
            border: 1px solid rgba(255,255,255,0.12);
            box-shadow: 0 8px 30px rgba(0,0,0,0.3);
        }
        .register-box h1 {
            font-size: 1.8rem;       /* titre plus petit */
            font-weight: 800;
            text-align: center;
            margin-bottom: 4px;
        }
        .register-box h1 i { color: #a5d6a7; margin-right: 8px; }
        .register-box .subtitle {
            text-align: center;
            color: rgba(255,255,255,0.7);
            margin-bottom: 20px;
            font-size: 0.95rem;
            font-weight: 300;
        }
        .register-box label {
            display: block;
            font-weight: 600;
            margin: 10px 0 3px;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.9);
        }
        .register-box input,
        .register-box textarea {
            width: 100%;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.2);
            background: rgba(255,255,255,0.08);
            color: #fff;
            font-size: 0.95rem;
            transition: 0.3s;
            font-family: inherit;
        }
        .register-box input:focus,
        .register-box textarea:focus {
            outline: none;
            border-color: #a5d6a7;
            background: rgba(255,255,255,0.15);
            box-shadow: 0 0 0 4px rgba(46, 125, 50, 0.2);
        }
        .register-box input::placeholder,
        .register-box textarea::placeholder { color: rgba(255,255,255,0.4); }
        .register-box textarea { min-height: 60px; resize: vertical; }
        .register-box .code-hint {
            background: rgba(46, 125, 50, 0.2);
            padding: 10px 14px;
            border-radius: 10px;
            border-left: 4px solid #a5d6a7;
            margin-bottom: 16px;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.9);
        }
        .register-box .code-hint i { color: #a5d6a7; margin-right: 8px; }
        .register-box button {
            width: 100%;
            padding: 12px;
            background: #2e7d32;
            color: #fff;
            border: none;
            border-radius: 50px;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 12px;
            box-shadow: 0 6px 20px rgba(46, 125, 50, 0.3);
        }
        .register-box button:hover {
            background: #1a3c2a;
            transform: translateY(-2px);
        }
        .register-box .links {
            text-align: center;
            margin-top: 16px;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.6);
        }
        .register-box .links a {
            color: #a5d6a7;
            font-weight: 600;
        }
        .register-box .links a:hover { text-decoration: underline; }

        .alert {
            padding: 10px 14px;
            border-radius: 12px;
            margin-bottom: 16px;
            border-left: 4px solid;
            font-size: 0.95rem;
        }
        .alert-success {
            background: rgba(46, 125, 50, 0.25);
            border-color: #2e7d32;
            color: #a5d6a7;
        }
        .alert-danger {
            background: rgba(244, 67, 54, 0.2);
            border-color: #f44336;
            color: #ffcdd2;
        }
        .alert a { color: #fff; font-weight: 700; text-decoration: underline; }

        /* FOOTER compact */
        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 20px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }
        .main-footer .footer-bottom i { color: #a5d6a7; }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .register-box { padding: 20px 18px; max-width: 100%; }
            .register-box h1 { font-size: 1.5rem; }
        }
        @media (max-width: 480px) {
            .main-content { padding: 100px 0 30px; }
            .register-box { padding: 16px 14px; }
        }
    </style>
</head>
<body>


<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">
        <div class="register-box">
            <h1><i class="fas fa-utensils"></i> Devenir traiteur</h1>
            <p class="subtitle">Inscrivez votre service sur <?= SITE_NAME ?></p>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>

            <?php if (!$success): ?>
            <form method="POST">
                <div class="code-hint">
                    <i class="fas fa-key"></i> 
                    Code à 5 chiffres reçu de l'administrateur.
                </div>

                <label>Code d'invitation <span style="color:#ffcdd2;">*</span></label>
                <input type="text" name="code" placeholder="Ex: 48123" maxlength="5" required style="text-align:center; font-size:1.3rem; letter-spacing:4px; font-weight:bold;">

                <label>Email <span style="color:#ffcdd2;">*</span></label>
                <input type="email" name="email" placeholder="votre@email.com" required>

                <label>Mot de passe <span style="color:#ffcdd2;">*</span> (min 6 caractères)</label>
                <input type="password" name="password" placeholder="••••••••" minlength="6" required>

                <label>Confirmer le mot de passe <span style="color:#ffcdd2;">*</span></label>
                <input type="password" name="confirm_password" placeholder="••••••••" required>

                <button type="submit"><i class="fas fa-user-plus"></i> Créer mon compte</button>
            </form>
            <?php endif; ?>

            <div class="links">
                <p>Déjà inscrit ? <a href="login.php">Connectez-vous</a></p>
                <p><a href="../index.php"><i class="fas fa-arrow-left"></i> Retour à l'accueil</a></p>
            </div>
        </div>
    </div>
</main>

<script>
    window.addEventListener('scroll', function() {
        const header = document.getElementById('mainHeader');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>
</body>
</html>