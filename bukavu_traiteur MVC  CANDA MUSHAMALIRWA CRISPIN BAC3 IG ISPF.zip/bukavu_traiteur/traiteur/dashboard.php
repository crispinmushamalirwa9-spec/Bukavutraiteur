<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'traiteur') {
    header('Location: login.php');
    exit;
}

// Récupérer les infos du traiteur AVEC la date de création depuis users
$stmt = $pdo->prepare("
    SELECT tp.*, u.created_at 
    FROM traiteur_profiles tp
    JOIN users u ON tp.user_id = u.id
    WHERE tp.user_id = ?
");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

if (!$profile) {
    die('Profil traiteur introuvable.');
}

// Statistiques des commandes
$order_stats = get_traiteur_order_stats($pdo, $user_id);

// Récupérer les 5 dernières commandes
$stmt = $pdo->prepare("
    SELECT o.*, cp.full_name as client_name 
    FROM orders o
    JOIN client_profiles cp ON o.client_id = cp.user_id
    WHERE o.traiteur_id = ?
    ORDER BY o.created_at DESC
    LIMIT 5
");
$stmt->execute([$user_id]);
$recent_orders = $stmt->fetchAll();

// Nombre total de posts
$stmt = $pdo->prepare("SELECT COUNT(*) FROM posts WHERE traiteur_id = ?");
$stmt->execute([$user_id]);
$total_posts = $stmt->fetchColumn();

// Nombre total de likes reçus
$stmt = $pdo->prepare("SELECT SUM(likes_count) FROM posts WHERE traiteur_id = ?");
$stmt->execute([$user_id]);
$total_likes = $stmt->fetchColumn() ?: 0;

// Récupérer les 5 dernières publications du traiteur
$stmt = $pdo->prepare("
    SELECT * FROM posts 
    WHERE traiteur_id = ? 
    ORDER BY created_at DESC 
    LIMIT 5
");
$stmt->execute([$user_id]);
$my_posts = $stmt->fetchAll();

// Récupérer les notifications non lues
$notifications = get_notifications($pdo, $user_id, 10);
mark_notifications_as_read($pdo, $user_id);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Traiteur - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }
        .welcome-box {
            background: rgba(255,255,255,0.05);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 30px;
            border-left: 4px solid #a5d6a7;
        }
        .welcome-box h1 {
            font-size: 1.8rem;
            font-weight: 700;
        }
        .welcome-box .rank {
            display: inline-block;
            background: #2e7d32;
            padding: 4px 16px;
            border-radius: 30px;
            font-weight: 600;
            margin-top: 6px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 20px;
        }
        .stat-card {
            background: rgba(255,255,255,0.06);
            border-radius: 16px;
            padding: 20px 16px;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.08);
            transition: 0.3s;
        }
        .stat-card:hover {
            background: rgba(255,255,255,0.12);
        }
        .stat-card .number {
            font-size: 2.6rem;
            font-weight: 800;
            color: #a5d6a7;
        }
        .stat-card .label {
            font-size: 0.9rem;
            color: rgba(255,255,255,0.7);
            margin-top: 4px;
        }
        .stat-card .icon {
            font-size: 2rem;
            color: rgba(255,255,255,0.2);
            margin-bottom: 8px;
        }

        .table-wrap {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }
        th {
            text-align: left;
            padding: 12px 12px;
            color: rgba(255,255,255,0.7);
            font-weight: 600;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        td {
            padding: 12px 12px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .badge {
            display: inline-block;
            padding: 3px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-warning { background: rgba(255, 193, 7, 0.3); color: #ffe082; }
        .badge-info { background: rgba(33, 150, 243, 0.3); color: #90caf9; }
        .badge-success { background: rgba(46, 125, 50, 0.3); color: #a5d6a7; }
        .badge-danger { background: rgba(244, 67, 54, 0.3); color: #ffcdd2; }

        /* Styles pour les publications */
        .my-posts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
        }
        .my-post-card {
            background: rgba(255,255,255,0.06);
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid rgba(255,255,255,0.08);
            transition: 0.3s;
        }
        .my-post-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
            background: rgba(255,255,255,0.1);
        }
        .my-post-card .media {
            width: 100%;
            height: 150px;
            object-fit: cover;
            background: rgba(0,0,0,0.3);
            display: block;
        }
        .my-post-card .media-placeholder {
            width: 100%;
            height: 150px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(0,0,0,0.4);
            color: rgba(255,255,255,0.3);
            font-size: 0.8rem;
        }
        .my-post-card .post-info {
            padding: 10px;
            font-size: 0.85rem;
        }
        .my-post-card .post-info .caption {
            color: rgba(255,255,255,0.8);
            margin-bottom: 4px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .my-post-card .post-info .likes {
            color: #ff6b6b;
            font-weight: 600;
        }
        .my-post-card .post-info .date {
            color: rgba(255,255,255,0.4);
            font-size: 0.75rem;
        }

        .notif-box {
            max-height: 200px;
            overflow-y: auto;
        }
        .notif-item {
            padding: 10px 0;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            font-size: 0.95rem;
        }
        .notif-item .date {
            float: right;
            color: rgba(255,255,255,0.4);
            font-size: 0.8rem;
        }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .my-posts-grid { grid-template-columns: 1fr 1fr; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="../index.php"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="create_post.php">Publier</a></li>
                <li><a href="manage_orders.php">Commandes</a></li>
                <li><a href="ranking.php">Classement</a></li>
                <li><a href="report_client.php">Signaler</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-utensil-spoon"></i> <?= htmlspecialchars($profile['service_name']) ?>
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <!-- Welcome -->
        <div class="welcome-box">
            <h1><i class="fas fa-hand-wave"></i> Bonjour, <?= htmlspecialchars($profile['service_name']) ?> !</h1>
            <p>📅 Membre depuis le <?= date('d/m/Y', strtotime($profile['created_at'])) ?></p>
            <p>⭐ Score de classement : <strong><?= number_format($profile['ranking_score'] ?? 0, 2) ?></strong></p>
            <span class="rank"><i class="fas fa-trophy"></i> Fidélisation : <?= number_format($profile['loyalty_score'] ?? 0, 2) ?> pts</span>
        </div>

        <!-- Statistiques -->
        <div class="section">
            <h2><i class="fas fa-chart-pie"></i> Vue d'ensemble</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-clock"></i></div>
                    <div class="number"><?= $order_stats['en_attente'] ?></div>
                    <div class="label">En attente</div>
                </div>
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-spinner"></i></div>
                    <div class="number"><?= $order_stats['en_cours'] ?></div>
                    <div class="label">En cours</div>
                </div>
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-check-circle"></i></div>
                    <div class="number"><?= $order_stats['termine'] ?></div>
                    <div class="label">Terminées</div>
                </div>
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-times-circle"></i></div>
                    <div class="number"><?= $order_stats['refuse'] ?></div>
                    <div class="label">Refusées</div>
                </div>
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-images"></i></div>
                    <div class="number"><?= $total_posts ?></div>
                    <div class="label">Publications</div>
                </div>
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-heart"></i></div>
                    <div class="number"><?= $total_likes ?></div>
                    <div class="label">Likes reçus</div>
                </div>
            </div>
        </div>

        <!-- Dernières commandes -->
        <div class="section">
            <h2><i class="fas fa-clipboard-list"></i> Dernières commandes</h2>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Client</th>
                            <th>Description</th>
                            <th>Date cérémonie</th>
                            <th>Statut</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent_orders)): ?>
                            <tr><td colspan="4" style="text-align:center; color:rgba(255,255,255,0.4); padding:20px;">Aucune commande reçue.</td></tr>
                        <?php else: ?>
                            <?php foreach ($recent_orders as $order): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($order['client_name']) ?></strong></td>
                                    <td><?= htmlspecialchars(substr($order['description'], 0, 40)) . (strlen($order['description']) > 40 ? '...' : '') ?></td>
                                    <td><?= date('d/m/Y', strtotime($order['ceremony_date'])) ?></td>
                                    <td>
                                        <span class="badge badge-<?= $order['status'] === 'en_attente' ? 'warning' : ($order['status'] === 'en_cours' ? 'info' : ($order['status'] === 'termine' ? 'success' : 'danger')) ?>">
                                            <?= $order['status'] ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <p style="text-align:right; margin-top:15px;">
                    <a href="manage_orders.php" style="color:#a5d6a7; font-weight:600;">Voir toutes les commandes →</a>
                </p>
            </div>
        </div>

        <!-- MES PUBLICATIONS -->
        <div class="section">
            <h2><i class="fas fa-images"></i> Mes publications</h2>
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; margin-bottom:15px;">
                <span style="color:rgba(255,255,255,0.6);"><?= $total_posts ?> publication(s) au total</span>
                <a href="create_post.php" style="background:#2e7d32; color:#fff; padding:6px 18px; border-radius:30px; font-weight:600; font-size:0.9rem;">
                    <i class="fas fa-plus"></i> Nouvelle publication
                </a>
            </div>

            <?php if (empty($my_posts)): ?>
                <div style="text-align:center; padding:30px; color:rgba(255,255,255,0.4);">
                    <i class="fas fa-camera" style="font-size:2.5rem; display:block; margin-bottom:10px;"></i>
                    <p>Vous n'avez pas encore de publications.</p>
                    <p><a href="create_post.php" style="color:#a5d6a7; font-weight:600;">Créez votre première publication →</a></p>
                </div>
            <?php else: ?>
                <div class="my-posts-grid">
                    <?php foreach ($my_posts as $post): ?>
                        <div class="my-post-card">
                            <?php render_media($post['media_path'], 'posts', 'media'); ?>
                            <div class="post-info">
                                <?php if (!empty($post['caption'])): ?>
                                    <div class="caption"><?= htmlspecialchars($post['caption']) ?></div>
                                <?php endif; ?>
                                <div class="likes"><i class="fas fa-heart"></i> <?= $post['likes_count'] ?> likes</div>
                                <div class="date"><?= date('d/m/Y', strtotime($post['created_at'])) ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if ($total_posts > 5): ?>
                    <p style="text-align:right; margin-top:15px;">
                        <a href="view_my_posts.php" style="color:#a5d6a7; font-weight:600;">Voir toutes mes publications →</a>
                    </p>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- Notifications -->
        <div class="section">
            <h2><i class="fas fa-bell"></i> Notifications</h2>
            <div class="notif-box">
                <?php if (empty($notifications)): ?>
                    <p style="color:rgba(255,255,255,0.4);">Aucune notification</p>
                <?php else: ?>
                    <?php foreach ($notifications as $notif): ?>
                        <div class="notif-item">
                            <?= htmlspecialchars($notif['message']) ?>
                            <span class="date"><?= date('d/m/Y H:i', strtotime($notif['created_at'])) ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
</main>

<script>
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>