<?php
// /client/logout.php
// Déconnexion du client

session_start();
session_destroy();

// Redirection vers la page d'accueil
header('Location: ../index.php?logout=success');
exit;