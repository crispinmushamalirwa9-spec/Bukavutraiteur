<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$client_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$client_id || $user_role !== 'client') {
    header('Location: login.php');
    exit;
}

// Récupérer le client pour le header
$stmt = $pdo->prepare("SELECT full_name FROM client_profiles WHERE user_id = ?");
$stmt->execute([$client_id]);
$client = $stmt->fetch();

$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
if ($order_id <= 0) {
    header('Location: dashboard.php');
    exit;
}

// Vérifier que la commande appartient bien au client, est terminée et n'a pas encore d'avis
$stmt = $pdo->prepare("
    SELECT o.*, tp.service_name 
    FROM orders o
    JOIN traiteur_profiles tp ON o.traiteur_id = tp.user_id
    WHERE o.id = ? AND o.client_id = ? AND o.status = 'termine'
");
$stmt->execute([$order_id, $client_id]);
$order = $stmt->fetch();

if (!$order) {
    echo '<p style="text-align:center; color:rgba(255,255,255,0.6);">Commande introuvable, non terminée, ou déjà évaluée.</p>';
    require_once __DIR__ . '/../includes/layouts/footer.php';
    exit;
}

// Vérifier si un avis existe déjà pour cette commande
$check = $pdo->prepare("SELECT id FROM reviews WHERE order_id = ?");
$check->execute([$order_id]);
if ($check->rowCount() > 0) {
    echo '<p style="text-align:center; color:rgba(255,255,255,0.6);">Vous avez déjà laissé un avis pour cette commande.</p>';
    require_once __DIR__ . '/../includes/layouts/footer.php';
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = $_POST['rating'] ?? '';
    $comment = trim($_POST['comment'] ?? '');

    if (empty($rating) || empty($comment)) {
        $error = 'Veuillez sélectionner un avis et écrire un commentaire.';
    } else {
        $traiteur_id = $order['traiteur_id'];
        try {
            $insert = $pdo->prepare("
                INSERT INTO reviews (order_id, client_id, traiteur_id, rating, comment)
                VALUES (?, ?, ?, ?, ?)
            ");
            $insert->execute([$order_id, $client_id, $traiteur_id, $rating, $comment]);

            // Mettre à jour le score de classement
            update_all_rankings($pdo);

            // Notifier le traiteur
            $rating_label = ($rating === 'positif') ? 'positif' : 'négatif';
            add_notification($pdo, $traiteur_id, "Avis $rating_label reçu pour la commande #$order_id.");

            $success = '✅ Merci pour votre avis ! Il a bien été enregistré et impacte le classement du traiteur.';
        } catch (Exception $e) {
            $error = 'Une erreur technique est survenue. Veuillez réessayer.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laisser un avis - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        .alert-success {
            background: rgba(46, 125, 50, 0.2);
            border-color: #2e7d32;
            color: #a5d6a7;
        }
        .alert-danger {
            background: rgba(244, 67, 54, 0.2);
            border-color: #f44336;
            color: #ffcdd2;
        }

        .form-group {
            margin-bottom: 18px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.8);
            margin-bottom: 4px;
        }
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            color: #fff;
            font-size: 1rem;
            transition: 0.3s;
            font-family: inherit;
        }
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #a5d6a7;
            background: rgba(255,255,255,0.12);
            box-shadow: 0 0 0 4px rgba(46, 125, 50, 0.15);
        }
        .form-group select option {
            background: #1a1a2e;
            color: #fff;
        }
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }

        .btn-submit {
            background: #2e7d32;
            color: #fff;
            border: none;
            padding: 14px 30px;
            border-radius: 60px;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            transition: 0.3s;
            width: 100%;
            box-shadow: 0 8px 25px rgba(46, 125, 50, 0.3);
        }
        .btn-submit:hover {
            background: #1a3c2a;
            transform: translateY(-2px);
        }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="../index.php"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="browse_posts.php">Publications</a></li>
                <li><a href="browse_by_service.php">Par service</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-user-circle"></i> <?= htmlspecialchars($client['full_name'] ?? 'Client') ?>
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <div class="section">
            <h2><i class="fas fa-star"></i> Laisser un avis</h2>
            <p style="color:rgba(255,255,255,0.6); margin-bottom:20px;">
                Commande #<?= $order_id ?> – Traiteur : <strong style="color:#a5d6a7;"><?= htmlspecialchars($order['service_name']) ?></strong>
            </p>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
                <p style="text-align:center; margin-top:15px;"><a href="dashboard.php" style="color:#a5d6a7; font-weight:600;">Retour à mes commandes</a></p>
            <?php else: ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>

                <form method="POST">
                    <div class="form-group">
                        <label>Votre avis <span style="color:#ffcdd2;">*</span></label>
                        <select name="rating" required>
                            <option value="">-- Choisissez --</option>
                            <option value="positif">✅ Positif</option>
                            <option value="negatif">❌ Négatif</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Commentaire <span style="color:#ffcdd2;">*</span></label>
                        <textarea name="comment" placeholder="Décrivez votre expérience avec ce traiteur..." required></textarea>
                    </div>

                    <button type="submit" class="btn-submit"><i class="fas fa-paper-plane"></i> Publier l'avis</button>
                </form>
            <?php endif; ?>
        </div>

    </div>
</main>
<script>
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>