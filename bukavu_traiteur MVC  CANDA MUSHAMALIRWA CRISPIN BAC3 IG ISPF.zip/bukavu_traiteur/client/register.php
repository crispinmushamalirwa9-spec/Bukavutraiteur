<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if ($user_id && $user_role === 'client') {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validation
    if (empty($full_name) || empty($email) || empty($password)) {
        $error = 'Veuillez remplir tous les champs obligatoires.';
    } elseif ($password !== $confirm_password) {
        $error = 'Les mots de passe ne correspondent pas.';
    } elseif (strlen($password) < 6) {
        $error = 'Le mot de passe doit contenir au moins 6 caractères.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Adresse email invalide.';
    } else {
        // Vérifier si l'email existe déjà
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->rowCount() > 0) {
            $error = 'Cet email est déjà utilisé. <a href="login.php" style="color:#a5d6a7; font-weight:600;">Connectez-vous</a>';
        } else {
            try {
                $pdo->beginTransaction();

                $password_hash = password_hash($password, PASSWORD_DEFAULT);

                // Création de l'utilisateur
                $insertUser = $pdo->prepare("INSERT INTO users (email, password_hash, role, status) VALUES (?, ?, 'client', 'actif')");
                $insertUser->execute([$email, $password_hash]);
                $user_id = $pdo->lastInsertId();

                // Création du profil client
                $insertProfile = $pdo->prepare("INSERT INTO client_profiles (user_id, full_name, phone) VALUES (?, ?, ?)");
                $insertProfile->execute([$user_id, $full_name, $phone]);

                $pdo->commit();

                $success = '✅ Compte client créé avec succès ! <a href="login.php" style="color:#a5d6a7; font-weight:600;">Connectez-vous</a> pour découvrir les traiteurs.';

            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Une erreur technique est survenue. Veuillez réessayer.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription Client - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #0f0f0f;
            color: #fff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background-image: url('../assets/images/justine.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-blend-mode: overlay;
            background-color: rgba(0,0,0,0.6);
        }
        .register-container {
            background: rgba(0, 0, 0, 0.55);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            padding: 40px 35px;
            border-radius: 28px;
            max-width: 460px;
            width: 90%;
            box-shadow: 0 20px 50px rgba(0,0,0,0.6);
            border: 1px solid rgba(255,255,255,0.08);
            text-align: center;
            margin: 20px;
        }
        .register-container .icon {
            font-size: 3rem;
            color: #a5d6a7;
            margin-bottom: 10px;
        }
        .register-container h1 {
            font-size: 1.8rem;
            font-weight: 800;
            margin-bottom: 6px;
        }
        .register-container .sub {
            color: rgba(255,255,255,0.6);
            font-weight: 300;
            margin-bottom: 25px;
        }
        .register-container .error {
            background: rgba(244, 67, 54, 0.15);
            border-left: 4px solid #f44336;
            padding: 12px 16px;
            border-radius: 12px;
            color: #ffcdd2;
            font-size: 0.95rem;
            margin-bottom: 20px;
            text-align: left;
        }
        .register-container .success {
            background: rgba(46, 125, 50, 0.2);
            border-left: 4px solid #2e7d32;
            padding: 12px 16px;
            border-radius: 12px;
            color: #a5d6a7;
            font-size: 0.95rem;
            margin-bottom: 20px;
            text-align: left;
        }
        .register-container label {
            display: block;
            font-weight: 600;
            font-size: 0.9rem;
            text-align: left;
            margin: 12px 0 4px;
            color: rgba(255,255,255,0.8);
        }
        .register-container input {
            width: 100%;
            padding: 12px 16px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            color: #fff;
            font-size: 1rem;
            transition: 0.3s;
        }
        .register-container input:focus {
            outline: none;
            border-color: #a5d6a7;
            background: rgba(255,255,255,0.12);
            box-shadow: 0 0 0 4px rgba(46, 125, 50, 0.15);
        }
        .register-container input::placeholder {
            color: rgba(255,255,255,0.3);
        }
        .register-container .benefits {
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 20px;
            text-align: left;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.7);
        }
        .register-container .benefits i {
            color: #a5d6a7;
            margin-right: 8px;
        }
        .register-container .benefits p {
            margin: 4px 0;
        }
        .register-container button {
            width: 100%;
            padding: 14px;
            margin-top: 20px;
            background: #2e7d32;
            border: none;
            border-radius: 60px;
            color: #fff;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            transition: 0.3s;
            box-shadow: 0 8px 25px rgba(46, 125, 50, 0.35);
        }
        .register-container button:hover {
            background: #1a3c2a;
            transform: translateY(-2px);
        }
        .register-container .links {
            margin-top: 20px;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.5);
        }
        .register-container .links a {
            color: #a5d6a7;
            font-weight: 600;
            text-decoration: none;
        }
        .register-container .links a:hover {
            text-decoration: underline;
        }
        .footer-note {
            margin-top: 30px;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.3);
            text-align: center;
        }
        @media (max-width: 480px) {
            .register-container { padding: 30px 20px; }
        }
    </style>
</head>
<body>

    <div class="register-container">
        <div class="icon"><i class="fas fa-user-plus"></i></div>
        <h1>Espace Client</h1>
        <p class="sub">Créez votre compte pour passer commande</p>

        <?php if ($error): ?>
            <div class="error"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="success"><i class="fas fa-check-circle"></i> <?= $success ?></div>
        <?php endif; ?>

        <?php if (!$success): ?>
        <div class="benefits">
            <p><i class="fas fa-check-circle"></i> Accédez à tous les traiteurs de Bukavu</p>
            <p><i class="fas fa-check-circle"></i> Passez vos commandes en quelques clics</p>
            <p><i class="fas fa-check-circle"></i> Notez et évaluez les services</p>
        </div>

        <form method="POST" action="">
            <label for="full_name">Nom complet <span style="color:#ffcdd2;">*</span></label>
            <input type="text" id="full_name" name="full_name" placeholder="Ex: Jean Mukeba" required>

            <label for="phone">Téléphone</label>
            <input type="text" id="phone" name="phone" placeholder="Ex: +243 82 000 0000">

            <label for="email">Email <span style="color:#ffcdd2;">*</span></label>
            <input type="email" id="email" name="email" placeholder="votre@email.com" required>

            <label for="password">Mot de passe <span style="color:#ffcdd2;">*</span> (min 6 caractères)</label>
            <input type="password" id="password" name="password" placeholder="••••••••" minlength="6" required>

            <label for="confirm_password">Confirmer le mot de passe <span style="color:#ffcdd2;">*</span></label>
            <input type="password" id="confirm_password" name="confirm_password" placeholder="••••••••" required>

            <button type="submit"><i class="fas fa-user-check"></i> Créer mon compte client</button>
        </form>
        <?php endif; ?>

        <div class="links">
            <p>Déjà inscrit ? <a href="login.php">Connectez-vous</a></p>
            <p><a href="../index.php"><i class="fas fa-arrow-left"></i> Retour à l'accueil</a></p>
        </div>
    </div>

    <div class="footer-note">
        &copy; <?= date('Y') ?> BukavuTraiteur – Tous droits réservés.
    </div>

</body>
</html>