<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'client') {
    header('Location: login.php');
    exit;
}

// Récupérer les infos du client AVEC la date de création depuis users
$stmt = $pdo->prepare("
    SELECT cp.*, u.created_at 
    FROM client_profiles cp
    JOIN users u ON cp.user_id = u.id
    WHERE cp.user_id = ?
");
$stmt->execute([$user_id]);
$client = $stmt->fetch();

if (!$client) {
    die('Profil client introuvable.');
}

// Récupérer les commandes du client
$stmt = $pdo->prepare("
    SELECT o.*, tp.service_name as traiteur_name, tp.profile_pic, st.name as service_type
    FROM orders o
    JOIN traiteur_profiles tp ON o.traiteur_id = tp.user_id
    LEFT JOIN service_types st ON o.service_type_id = st.id
    WHERE o.client_id = ?
    ORDER BY FIELD(o.status, 'en_attente', 'en_cours', 'termine', 'refuse'), o.created_at DESC
");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();

// Statistiques des commandes
$stats = ['en_attente' => 0, 'en_cours' => 0, 'termine' => 0, 'refuse' => 0];
foreach ($orders as $o) {
    $stats[$o['status']]++;
}

// Récupérer les notifications
$notifications = get_notifications($pdo, $user_id, 10);
mark_notifications_as_read($pdo, $user_id);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }

        .welcome-box {
            background: rgba(255,255,255,0.05);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 30px;
            border-left: 4px solid #a5d6a7;
        }
        .welcome-box h1 {
            font-size: 1.8rem;
            font-weight: 700;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 20px;
        }
        .stat-card {
            background: rgba(255,255,255,0.06);
            border-radius: 16px;
            padding: 20px 16px;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.08);
            transition: 0.3s;
        }
        .stat-card:hover {
            background: rgba(255,255,255,0.12);
        }
        .stat-card .number {
            font-size: 2.6rem;
            font-weight: 800;
            color: #a5d6a7;
        }
        .stat-card .label {
            font-size: 0.9rem;
            color: rgba(255,255,255,0.7);
            margin-top: 4px;
        }
        .stat-card .icon {
            font-size: 2rem;
            color: rgba(255,255,255,0.2);
            margin-bottom: 8px;
        }

        .table-wrap {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }
        th {
            text-align: left;
            padding: 12px 12px;
            color: rgba(255,255,255,0.7);
            font-weight: 600;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        td {
            padding: 12px 12px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            vertical-align: middle;
        }
        .badge {
            display: inline-block;
            padding: 3px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-warning { background: rgba(255, 193, 7, 0.3); color: #ffe082; }
        .badge-info { background: rgba(33, 150, 243, 0.3); color: #90caf9; }
        .badge-success { background: rgba(46, 125, 50, 0.3); color: #a5d6a7; }
        .badge-danger { background: rgba(244, 67, 54, 0.3); color: #ffcdd2; }

        .notif-box {
            max-height: 200px;
            overflow-y: auto;
        }
        .notif-item {
            padding: 10px 0;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            font-size: 0.95rem;
        }
        .notif-item .date {
            float: right;
            color: rgba(255,255,255,0.4);
            font-size: 0.8rem;
        }

        .traiteur-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            vertical-align: middle;
            margin-right: 10px;
            background: rgba(255,255,255,0.05);
        }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="../index.php"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="browse_posts.php">Publications</a></li>
                <li><a href="browse_by_service.php">Par service</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-user-circle"></i> <?= htmlspecialchars($client['full_name']) ?>
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <div class="welcome-box">
            <h1><i class="fas fa-hand-wave"></i> Bonjour, <?= htmlspecialchars($client['full_name']) ?> !</h1>
            <p>📅 Membre depuis le <?= date('d/m/Y', strtotime($client['created_at'])) ?></p>
            <p>📞 <?= htmlspecialchars($client['phone'] ?? 'Téléphone non renseigné') ?></p>
        </div>

        <!-- Statistiques -->
        <div class="section">
            <h2><i class="fas fa-chart-pie"></i> Vue d'ensemble</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-clock"></i></div>
                    <div class="number"><?= $stats['en_attente'] ?></div>
                    <div class="label">En attente</div>
                </div>
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-spinner"></i></div>
                    <div class="number"><?= $stats['en_cours'] ?></div>
                    <div class="label">En cours</div>
                </div>
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-check-circle"></i></div>
                    <div class="number"><?= $stats['termine'] ?></div>
                    <div class="label">Terminées</div>
                </div>
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-times-circle"></i></div>
                    <div class="number"><?= $stats['refuse'] ?></div>
                    <div class="label">Refusées</div>
                </div>
            </div>
        </div>

        <!-- Liste des commandes -->
        <div class="section">
            <h2><i class="fas fa-clipboard-list"></i> Mes commandes</h2>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Traiteur</th>
                            <th>Service</th>
                            <th>Date cérémonie</th>
                            <th>Statut</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($orders)): ?>
                            <tr><td colspan="5" style="text-align:center; color:rgba(255,255,255,0.4); padding:30px;">
                                Vous n'avez encore passé aucune commande.<br>
                                <a href="browse_posts.php" style="color:#a5d6a7; font-weight:600;">Explorer les traiteurs →</a>
                            </td></tr>
                        <?php else: ?>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td>
                                        <img src="<?= SITE_URL ?>assets/uploads/profiles/<?= htmlspecialchars($order['profile_pic'] ?? 'default_traiteur.jpg') ?>" class="traiteur-avatar">
                                        <?= htmlspecialchars($order['traiteur_name']) ?>
                                    </td>
                                    <td><?= htmlspecialchars($order['service_type'] ?? 'Non précisé') ?></td>
                                    <td><?= date('d/m/Y', strtotime($order['ceremony_date'])) ?></td>
                                    <td>
                                        <span class="badge badge-<?= $order['status'] === 'en_attente' ? 'warning' : ($order['status'] === 'en_cours' ? 'info' : ($order['status'] === 'termine' ? 'success' : 'danger')) ?>">
                                            <?= $order['status'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($order['status'] === 'termine'): ?>
                                            <?php 
                                                // Vérifier si un avis existe déjà
                                                $check_review = $pdo->prepare("SELECT id FROM reviews WHERE order_id = ?");
                                                $check_review->execute([$order['id']]);
                                                if ($check_review->rowCount() > 0) {
                                                    echo '<span style="color:rgba(255,255,255,0.4);">Avis donné</span>';
                                                } else {
                                                    echo '<a href="leave_review.php?order_id='.$order['id'].'" style="color:#a5d6a7; font-weight:600;">Donner un avis</a>';
                                                }
                                            ?>
                                        <?php else: ?>
                                            <span style="color:rgba(255,255,255,0.3);">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Notifications -->
        <div class="section">
            <h2><i class="fas fa-bell"></i> Notifications</h2>
            <div class="notif-box">
                <?php if (empty($notifications)): ?>
                    <p style="color:rgba(255,255,255,0.4);">Aucune notification</p>
                <?php else: ?>
                    <?php foreach ($notifications as $notif): ?>
                        <div class="notif-item">
                            <?= htmlspecialchars($notif['message']) ?>
                            <span class="date"><?= date('d/m/Y H:i', strtotime($notif['created_at'])) ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
</main>

<script>
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>