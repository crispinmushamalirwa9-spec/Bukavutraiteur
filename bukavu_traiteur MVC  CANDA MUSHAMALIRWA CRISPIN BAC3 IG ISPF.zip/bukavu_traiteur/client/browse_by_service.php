<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'client') {
    header('Location: login.php');
    exit;
}

// Récupérer les infos du client pour le header
$stmt = $pdo->prepare("SELECT full_name FROM client_profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$client = $stmt->fetch();

// Récupérer la liste des services
$services = get_all_service_types($pdo);

$selected_service = isset($_GET['service_id']) ? (int)$_GET['service_id'] : 0;
$traiteurs = [];

if ($selected_service > 0) {
    $traiteurs = get_traiteurs_by_service($pdo, $selected_service);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rechercher par service - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }

        .filter-box {
            background: rgba(255,255,255,0.05);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 30px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 15px;
        }
        .filter-box select {
            flex: 1;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            color: #fff;
            font-size: 1rem;
            min-width: 200px;
            transition: 0.3s;
        }
        .filter-box select:focus {
            outline: none;
            border-color: #a5d6a7;
            background: rgba(255,255,255,0.12);
            box-shadow: 0 0 0 4px rgba(46, 125, 50, 0.15);
        }
        .filter-box select option {
            background: #1a1a2e;
            color: #fff;
        }
        .filter-box button {
            padding: 12px 28px;
            border-radius: 60px;
            border: none;
            background: #2e7d32;
            color: #fff;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: 0.3s;
            box-shadow: 0 8px 25px rgba(46, 125, 50, 0.3);
        }
        .filter-box button:hover {
            background: #1a3c2a;
            transform: translateY(-2px);
        }

        .traiteurs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 30px;
        }
        .traiteur-card {
            background: rgba(255,255,255,0.06);
            border-radius: 16px;
            overflow: hidden;
            transition: 0.3s;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .traiteur-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
            background: rgba(255,255,255,0.1);
        }
        .traiteur-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: rgba(0,0,0,0.3);
            display: block;
        }
        .traiteur-card .card-body {
            padding: 16px;
        }
        .traiteur-card .card-body h3 {
            font-weight: 700;
            font-size: 1.2rem;
            margin-bottom: 4px;
        }
        .traiteur-card .card-body .location {
            color: rgba(255,255,255,0.6);
            font-size: 0.9rem;
            margin-bottom: 8px;
        }
        .traiteur-card .card-body .score {
            display: inline-block;
            background: rgba(46, 125, 50, 0.3);
            color: #a5d6a7;
            padding: 4px 12px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 0.9rem;
            margin-bottom: 12px;
        }
        .traiteur-card .card-body .btn-view {
            display: inline-block;
            margin-top: 10px;
            color: #a5d6a7;
            font-weight: 600;
            transition: 0.3s;
        }
        .traiteur-card .card-body .btn-view:hover {
            color: #fff;
            text-decoration: underline;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: rgba(255,255,255,0.4);
        }
        .empty-state i {
            font-size: 3rem;
            color: rgba(255,255,255,0.2);
            margin-bottom: 15px;
            display: block;
        }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
            .filter-box { flex-direction: column; align-items: stretch; }
            .traiteurs-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="../index.php"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="browse_posts.php">Publications</a></li>
                <li><a href="browse_by_service.php">Par service</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-user-circle"></i> <?= htmlspecialchars($client['full_name'] ?? 'Client') ?>
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <div class="section">
            <h2><i class="fas fa-filter"></i> Rechercher par type de service</h2>
            <p style="color:rgba(255,255,255,0.6); margin-bottom:20px;">Choisissez un type de cérémonie pour voir les traiteurs spécialisés.</p>

            <div class="filter-box">
                <form method="GET" action="">
                    <select name="service_id">
                        <option value="0">-- Sélectionnez un service --</option>
                        <?php foreach ($services as $s): ?>
                            <option value="<?= $s['id'] ?>" <?= $selected_service == $s['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($s['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit"><i class="fas fa-search"></i> Filtrer</button>
                </form>
            </div>

            <?php if ($selected_service > 0): ?>
                <?php if (empty($traiteurs)): ?>
                    <div class="empty-state">
                        <i class="fas fa-utensils"></i>
                        <p>Aucun traiteur ne propose ce service pour le moment.</p>
                    </div>
                <?php else: ?>
                    <div class="traiteurs-grid">
                        <?php foreach ($traiteurs as $t): ?>
                            <div class="traiteur-card">
                                <img src="<?= SITE_URL ?>assets/uploads/profiles/<?= htmlspecialchars($t['profile_pic'] ?? 'default_traiteur.jpg') ?>" alt="<?= htmlspecialchars($t['service_name']) ?>">
                                <div class="card-body">
                                    <h3><?= htmlspecialchars($t['service_name']) ?></h3>
                                    <div class="location"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($t['address'] ?? 'Bukavu') ?></div>
                                    <span class="score"><i class="fas fa-star"></i> <?= number_format($t['ranking_score'] ?? 0, 1) ?></span>
                                    <br>
                                    <a href="view_traiteur.php?id=<?= $t['user_id'] ?>" class="btn-view">Voir le profil →</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-hand-pointer"></i>
                    <p>Sélectionnez un service ci-dessus pour afficher les traiteurs correspondants.</p>
                </div>
            <?php endif; ?>
        </div>

    </div>
</main>

<script>
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>