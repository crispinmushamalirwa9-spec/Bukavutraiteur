<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'client') {
    header('Location: login.php');
    exit;
}

// Récupérer les infos actuelles du client (avec created_at depuis users)
$stmt = $pdo->prepare("
    SELECT u.email, u.created_at, cp.* 
    FROM users u 
    JOIN client_profiles cp ON u.id = cp.user_id 
    WHERE u.id = ?
");
$stmt->execute([$user_id]);
$data = $stmt->fetch();

if (!$data) {
    die('Profil client introuvable.');
}

$error = '';
$success = '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validation
    if (empty($full_name) || empty($email)) {
        $error = 'Veuillez remplir tous les champs obligatoires.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Adresse email invalide.';
    } elseif (!empty($new_password) && $new_password !== $confirm_password) {
        $error = 'Les mots de passe ne correspondent pas.';
    } elseif (!empty($new_password) && strlen($new_password) < 6) {
        $error = 'Le nouveau mot de passe doit contenir au moins 6 caractères.';
    } else {
        // Vérifier si l'email est déjà utilisé par un autre compte
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $check->execute([$email, $user_id]);
        if ($check->rowCount() > 0) {
            $error = 'Cet email est déjà utilisé par un autre compte.';
        } else {
            try {
                $pdo->beginTransaction();

                // Mettre à jour l'email
                $upd = $pdo->prepare("UPDATE users SET email = ? WHERE id = ?");
                $upd->execute([$email, $user_id]);
                $_SESSION['user_email'] = $email;

                // Mettre à jour le profil client
                $upd2 = $pdo->prepare("
                    UPDATE client_profiles 
                    SET full_name = ?, phone = ? 
                    WHERE user_id = ?
                ");
                $upd2->execute([$full_name, $phone, $user_id]);

                // Changer le mot de passe si fourni
                if (!empty($new_password)) {
                    $hash = password_hash($new_password, PASSWORD_DEFAULT);
                    $upd3 = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                    $upd3->execute([$hash, $user_id]);
                }

                // Gérer la photo de profil
                if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
                    if (!is_dir(PROFILE_PICS_PATH)) {
                        mkdir(PROFILE_PICS_PATH, 0777, true);
                    }
                    $upload = upload_file($_FILES['profile_pic'], PROFILE_PICS_PATH);
                    if ($upload['success']) {
                        $upd4 = $pdo->prepare("UPDATE client_profiles SET profile_pic = ? WHERE user_id = ?");
                        $upd4->execute([$upload['filename'], $user_id]);
                    } else {
                        $error = $upload['message'];
                    }
                }

                if (empty($error)) {
                    $pdo->commit();
                    $success = '✅ Profil mis à jour avec succès !';
                    // Recharger les données
                    $stmt = $pdo->prepare("
                        SELECT u.email, u.created_at, cp.* 
                        FROM users u 
                        JOIN client_profiles cp ON u.id = cp.user_id 
                        WHERE u.id = ?
                    ");
                    $stmt->execute([$user_id]);
                    $data = $stmt->fetch();
                } else {
                    $pdo->rollBack();
                }
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Une erreur technique est survenue.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paramètres - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }
        .alert {
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        .alert-success {
            background: rgba(46, 125, 50, 0.2);
            border-color: #2e7d32;
            color: #a5d6a7;
        }
        .alert-danger {
            background: rgba(244, 67, 54, 0.2);
            border-color: #f44336;
            color: #ffcdd2;
        }

        .profile-pic {
            text-align: center;
            margin-bottom: 25px;
        }
        .profile-pic img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #a5d6a7;
            background: rgba(255,255,255,0.1);
        }
        .profile-pic input[type="file"] {
            display: block;
            margin: 10px auto;
            background: rgba(255,255,255,0.05);
            padding: 8px 12px;
            border-radius: 30px;
            border: 1px solid rgba(255,255,255,0.15);
            color: #fff;
            width: auto;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 18px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.8);
            margin-bottom: 4px;
        }
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            color: #fff;
            font-size: 1rem;
            transition: 0.3s;
            font-family: inherit;
        }
        .form-group textarea {
            min-height: 80px;
            resize: vertical;
        }
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #a5d6a7;
            background: rgba(255,255,255,0.12);
            box-shadow: 0 0 0 4px rgba(46, 125, 50, 0.15);
        }
        .form-group input::placeholder,
        .form-group textarea::placeholder {
            color: rgba(255,255,255,0.3);
        }
        .form-group .hint {
            color: rgba(255,255,255,0.4);
            font-size: 0.8rem;
            margin-top: 4px;
        }

        .btn-save {
            background: #2e7d32;
            color: #fff;
            border: none;
            padding: 14px 30px;
            border-radius: 60px;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            transition: 0.3s;
            width: 100%;
            box-shadow: 0 8px 25px rgba(46, 125, 50, 0.3);
        }
        .btn-save:hover {
            background: #1a3c2a;
            transform: translateY(-2px);
        }

        .logout-link {
            text-align: center;
            margin-top: 25px;
            border-top: 1px solid rgba(255,255,255,0.08);
            padding-top: 20px;
        }
        .logout-link a {
            color: #ffcdd2;
            font-weight: 600;
            transition: 0.3s;
        }
        .logout-link a:hover {
            color: #f44336;
            text-decoration: underline;
        }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="../index.php"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="browse_posts.php">Publications</a></li>
                <li><a href="browse_by_service.php">Par service</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-user-circle"></i> <?= htmlspecialchars($data['full_name']) ?>
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <div class="section">
            <h2><i class="fas fa-user-cog"></i> Mes paramètres</h2>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div class="profile-pic">
                    <img src="<?= SITE_URL ?>assets/uploads/profiles/<?= htmlspecialchars($data['profile_pic'] ?? 'default_client.jpg') ?>" alt="Photo de profil" id="preview">
                    <input type="file" name="profile_pic" accept="image/*" onchange="previewFile(this)">
                    <p style="color:rgba(255,255,255,0.4); font-size:0.8rem;">JPG, PNG, WEBP – max 10 Mo</p>
                </div>

                <div class="form-group">
                    <label>Nom complet <span style="color:#ffcdd2;">*</span></label>
                    <input type="text" name="full_name" value="<?= htmlspecialchars($data['full_name']) ?>" required>
                </div>

                <div class="form-group">
                    <label>Téléphone</label>
                    <input type="text" name="phone" value="<?= htmlspecialchars($data['phone']) ?>">
                </div>

                <div class="form-group">
                    <label>Email <span style="color:#ffcdd2;">*</span></label>
                    <input type="email" name="email" value="<?= htmlspecialchars($data['email']) ?>" required>
                </div>

                <div class="form-group">
                    <label>Nouveau mot de passe</label>
                    <input type="password" name="new_password" placeholder="Laissez vide pour ne pas changer" minlength="6">
                    <div class="hint">Min 6 caractères</div>
                </div>

                <div class="form-group">
                    <label>Confirmer le nouveau mot de passe</label>
                    <input type="password" name="confirm_password" placeholder="Confirmez le nouveau mot de passe">
                </div>

                <button type="submit" class="btn-save"><i class="fas fa-save"></i> Enregistrer les modifications</button>
            </form>

            <div class="logout-link">
                <a href="logout.php" onclick="return confirm('Confirmer la déconnexion ?')">
                    <i class="fas fa-sign-out-alt"></i> Se déconnecter
                </a>
            </div>
        </div>

    </div>
</main>

<script>
    function previewFile(input) {
        const preview = document.getElementById('preview');
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>