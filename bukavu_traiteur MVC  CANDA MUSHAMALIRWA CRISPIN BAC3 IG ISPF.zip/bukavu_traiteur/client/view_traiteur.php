<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$client_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$client_id || $user_role !== 'client') {
    header('Location: login.php');
    exit;
}

// Récupérer le client pour le header
$stmt = $pdo->prepare("SELECT full_name FROM client_profiles WHERE user_id = ?");
$stmt->execute([$client_id]);
$client = $stmt->fetch();

// Récupérer le traiteur
$traiteur_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($traiteur_id <= 0) {
    header('Location: browse_posts.php');
    exit;
}

// Infos du traiteur
$stmt = $pdo->prepare("
    SELECT tp.*, u.email, u.status,
           (SELECT COUNT(*) FROM orders WHERE traiteur_id = tp.user_id AND status = 'termine') as total_orders_done,
           (SELECT COUNT(*) FROM reviews WHERE traiteur_id = tp.user_id AND rating = 'positif') as positive_reviews,
           (SELECT COUNT(*) FROM reviews WHERE traiteur_id = tp.user_id AND rating = 'negatif') as negative_reviews
    FROM traiteur_profiles tp
    JOIN users u ON tp.user_id = u.id
    WHERE tp.user_id = ? AND u.status = 'actif'
");
$stmt->execute([$traiteur_id]);
$traiteur = $stmt->fetch();

if (!$traiteur) {
    echo '<p style="text-align:center; color:rgba(255,255,255,0.6); padding:40px;">Traiteur introuvable ou inactif.</p>';
    require_once __DIR__ . '/../includes/layouts/footer.php';
    exit;
}

// Publications du traiteur
$stmt = $pdo->prepare("SELECT * FROM posts WHERE traiteur_id = ? ORDER BY created_at DESC");
$stmt->execute([$traiteur_id]);
$posts = $stmt->fetchAll();

// Avis du traiteur
$stmt = $pdo->prepare("
    SELECT r.*, cp.full_name as client_name 
    FROM reviews r
    JOIN client_profiles cp ON r.client_id = cp.user_id
    WHERE r.traiteur_id = ?
    ORDER BY r.created_at DESC
");
$stmt->execute([$traiteur_id]);
$reviews = $stmt->fetchAll();

// Services proposés par le traiteur
$stmt = $pdo->prepare("
    SELECT st.name FROM traiteur_services ts
    JOIN service_types st ON ts.service_id = st.id
    WHERE ts.traiteur_id = ?
");
$stmt->execute([$traiteur_id]);
$services = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Calcul du classement général
$rank_stmt = $pdo->query("
    SELECT user_id, RANK() OVER (ORDER BY ranking_score DESC) as rank_position
    FROM traiteur_profiles
");
$ranks = $rank_stmt->fetchAll(PDO::FETCH_KEY_PAIR);
$rank_position = $ranks[$traiteur_id] ?? 'N/C';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - <?= htmlspecialchars($traiteur['service_name']) ?> - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }

        /* Profil header */
        .profile-header {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            align-items: center;
        }
        .profile-header img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #a5d6a7;
            background: rgba(255,255,255,0.05);
        }
        .profile-header .info {
            flex: 1;
        }
        .profile-header .info h1 {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 4px;
        }
        .profile-header .info .meta {
            color: rgba(255,255,255,0.6);
            font-size: 0.95rem;
        }
        .profile-header .info .meta i {
            margin-right: 4px;
            color: #a5d6a7;
        }
        .profile-header .info .badge-score {
            display: inline-block;
            background: rgba(46, 125, 50, 0.3);
            color: #a5d6a7;
            padding: 4px 16px;
            border-radius: 30px;
            font-weight: 700;
            margin: 8px 4px 8px 0;
        }
        .profile-header .info .badge-rank {
            display: inline-block;
            background: rgba(255, 193, 7, 0.2);
            color: #ffe082;
            padding: 4px 16px;
            border-radius: 30px;
            font-weight: 700;
        }
        .profile-header .info .description {
            margin-top: 12px;
            color: rgba(255,255,255,0.85);
        }
        .profile-header .info .btn-commander {
            display: inline-block;
            margin-top: 15px;
            background: #2e7d32;
            color: #fff;
            padding: 12px 30px;
            border-radius: 60px;
            font-weight: 700;
            transition: 0.3s;
            box-shadow: 0 8px 25px rgba(46, 125, 50, 0.3);
        }
        .profile-header .info .btn-commander:hover {
            background: #1a3c2a;
            transform: translateY(-2px);
        }

        /* Posts grid */
        .posts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 20px;
        }
        .post-item {
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid rgba(255,255,255,0.06);
            transition: 0.3s;
        }
        .post-item:hover {
            background: rgba(255,255,255,0.1);
        }
        .post-item img, .post-item video {
            width: 100%;
            height: 180px;
            object-fit: cover;
            display: block;
            background: rgba(0,0,0,0.3);
        }
        .post-item .caption {
            padding: 10px;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.8);
        }
        .post-item .likes {
            padding: 0 10px 10px;
            color: #ff6b6b;
            font-weight: 600;
            font-size: 0.85rem;
        }

        /* Reviews */
        .review-item {
            padding: 15px 0;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .review-item:last-child {
            border-bottom: none;
        }
        .review-item .rating-positif {
            color: #a5d6a7;
            font-weight: 700;
        }
        .review-item .rating-negatif {
            color: #ff6b6b;
            font-weight: 700;
        }
        .review-item .date {
            float: right;
            color: rgba(255,255,255,0.4);
            font-size: 0.8rem;
        }
        .review-item .comment {
            margin-top: 4px;
            color: rgba(255,255,255,0.8);
        }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
            .profile-header { flex-direction: column; text-align: center; }
            .profile-header img { width: 120px; height: 120px; }
            .posts-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="../index.php"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="browse_posts.php">Publications</a></li>
                <li><a href="browse_by_service.php">Par service</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-user-circle"></i> <?= htmlspecialchars($client['full_name'] ?? 'Client') ?>
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <!-- SECTION PROFIL -->
        <div class="section">
            <div class="profile-header">
                <img src="<?= SITE_URL ?>assets/uploads/profiles/<?= htmlspecialchars($traiteur['profile_pic'] ?? 'default_traiteur.jpg') ?>" alt="<?= htmlspecialchars($traiteur['service_name']) ?>">
                <div class="info">
                    <h1><?= htmlspecialchars($traiteur['service_name']) ?></h1>
                    <div class="meta">
                        <i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($traiteur['address']) ?>
                        <?php if (!empty($traiteur['phone'])): ?>
                            · <i class="fas fa-phone"></i> <?= htmlspecialchars($traiteur['phone']) ?>
                        <?php endif; ?>
                    </div>
                    <div>
                        <span class="badge-score"><i class="fas fa-star"></i> Score : <?= number_format($traiteur['ranking_score'] ?? 0, 2) ?></span>
                        <span class="badge-rank"><i class="fas fa-trophy"></i> Classement : #<?= $rank_position ?></span>
                    </div>
                    <p style="margin-top:6px; color:rgba(255,255,255,0.6);">
                        <strong>Expérience :</strong> <?= $traiteur['experience_years'] ?? 0 ?> ans · 
                        <strong>Fidélisation :</strong> <?= number_format($traiteur['loyalty_score'] ?? 0, 2) ?> pts · 
                        <strong>Commandes réalisées :</strong> <?= $traiteur['total_orders_done'] ?>
                    </p>
                    <?php if (!empty($services)): ?>
                        <p style="margin-top:6px; color:rgba(255,255,255,0.6);">
                            <i class="fas fa-tags"></i> <strong>Services :</strong> <?= implode(', ', array_map('htmlspecialchars', $services)) ?>
                        </p>
                    <?php endif; ?>
                    <?php if (!empty($traiteur['description'])): ?>
                        <div class="description"><?= nl2br(htmlspecialchars($traiteur['description'])) ?></div>
                    <?php endif; ?>
                    <a href="pass_order.php?traiteur_id=<?= $traiteur_id ?>" class="btn-commander">
                        <i class="fas fa-shopping-cart"></i> Passer une commande
                    </a>
                </div>
            </div>
        </div>

        <!-- SECTION PUBLICATIONS -->
        <div class="section">
            <h2><i class="fas fa-images"></i> Publications</h2>
            <?php if (empty($posts)): ?>
                <p style="color:rgba(255,255,255,0.4);">Ce traiteur n'a pas encore de publications.</p>
            <?php else: ?>
                <div class="posts-grid">
                    <?php foreach ($posts as $post): 
                        $ext = pathinfo($post['media_path'], PATHINFO_EXTENSION);
                        $is_video = in_array(strtolower($ext), ['mp4', 'webm', 'avi', 'mov']);
                        $media_path = SITE_URL . 'assets/uploads/posts/' . $post['media_path'];
                    ?>
                        <div class="post-item">
                            <?php if ($is_video): ?>
                                <video src="<?= $media_path ?>" controls></video>
                            <?php else: ?>
                                <img src="<?= $media_path ?>" alt="Publication">
                            <?php endif; ?>
                            <?php if (!empty($post['caption'])): ?>
                                <div class="caption"><?= htmlspecialchars($post['caption']) ?></div>
                            <?php endif; ?>
                            <div class="likes"><i class="fas fa-heart"></i> <?= $post['likes_count'] ?> likes</div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- SECTION AVIS -->
        <div class="section">
            <h2><i class="fas fa-comments"></i> Avis clients</h2>
            <?php if (empty($reviews)): ?>
                <p style="color:rgba(255,255,255,0.4);">Aucun avis pour le moment.</p>
            <?php else: ?>
                <?php foreach ($reviews as $review): ?>
                    <div class="review-item">
                        <strong><?= htmlspecialchars($review['client_name']) ?></strong>
                        <span class="rating-<?= $review['rating'] ?>">
                            <?= $review['rating'] === 'positif' ? '✅ Positif' : '❌ Négatif' ?>
                        </span>
                        <span class="date"><?= date('d/m/Y', strtotime($review['created_at'])) ?></span>
                        <?php if (!empty($review['comment'])): ?>
                            <div class="comment"><?= nl2br(htmlspecialchars($review['comment'])) ?></div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

    </div>
</main>

<script>
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>