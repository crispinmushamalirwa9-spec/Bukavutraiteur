<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'client') {
    header('Location: login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT full_name FROM client_profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$client = $stmt->fetch();

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 12;
$offset = ($page - 1) * $limit;

$count_stmt = $pdo->query("
    SELECT COUNT(*) 
    FROM posts p
    JOIN traiteur_profiles tp ON p.traiteur_id = tp.user_id
    JOIN users u ON tp.user_id = u.id
    WHERE u.status = 'actif'
");
$total_posts = $count_stmt->fetchColumn();
$total_pages = max(1, ceil($total_posts / $limit));

$stmt = $pdo->prepare("
    SELECT p.*, tp.service_name, tp.profile_pic, tp.user_id as traiteur_id
    FROM posts p
    JOIN traiteur_profiles tp ON p.traiteur_id = tp.user_id
    JOIN users u ON tp.user_id = u.id
    WHERE u.status = 'actif'
    ORDER BY p.created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute([$limit, $offset]);
$posts = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publications - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }

        .posts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 30px;
        }
        .post-card {
            background: rgba(255,255,255,0.06);
            border-radius: 16px;
            overflow: hidden;
            transition: 0.3s;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .post-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
            background: rgba(255,255,255,0.1);
        }
        .post-card .media {
            width: 100%;
            height: 220px;
            object-fit: cover;
            background: rgba(0,0,0,0.3);
            display: block;
        }
        .post-card .post-body {
            padding: 16px;
        }
        .post-card .post-body .traiteur-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 10px;
        }
        .post-card .post-body .traiteur-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.1);
            background: rgba(0,0,0,0.3);
        }
        .post-card .post-body .traiteur-info h4 {
            font-weight: 700;
            font-size: 1rem;
        }
        .post-card .post-body .traiteur-info .date {
            color: rgba(255,255,255,0.4);
            font-size: 0.8rem;
        }
        .post-card .post-body .caption {
            color: rgba(255,255,255,0.85);
            margin: 8px 0;
            font-size: 0.95rem;
        }
        .post-card .post-body .likes {
            color: #ff6b6b;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .post-card .post-body .likes i {
            margin-right: 4px;
        }
        .post-card .post-body .btn-profile {
            display: inline-block;
            margin-top: 10px;
            color: #a5d6a7;
            font-weight: 600;
            font-size: 0.9rem;
            transition: 0.3s;
        }
        .post-card .post-body .btn-profile:hover {
            color: #fff;
            text-decoration: underline;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: rgba(255,255,255,0.4);
        }
        .empty-state i {
            font-size: 3rem;
            color: rgba(255,255,255,0.2);
            margin-bottom: 15px;
            display: block;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 30px;
            flex-wrap: wrap;
        }
        .pagination a, .pagination span {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 30px;
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.08);
            color: rgba(255,255,255,0.7);
            transition: 0.3s;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .pagination a:hover {
            background: rgba(255,255,255,0.15);
            color: #fff;
        }
        .pagination .active {
            background: #2e7d32;
            border-color: #2e7d32;
            color: #fff;
        }
        .pagination .disabled {
            opacity: 0.3;
            cursor: not-allowed;
        }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
            .posts-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="../index.php"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="browse_posts.php">Publications</a></li>
                <li><a href="browse_by_service.php">Par service</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-user-circle"></i> <?= htmlspecialchars($client['full_name'] ?? 'Client') ?>
        </div>
    </div>
</header>

<main class="main-content">
    <div class="container">
        <div class="section">
            <h2><i class="fas fa-images"></i> Découvrez les traiteurs de Bukavu</h2>
            <p style="color:rgba(255,255,255,0.6); margin-bottom:20px;">Parcourez les photos et vidéos des services proposés par nos traiteurs.</p>

            <?php if (empty($posts)): ?>
                <div class="empty-state">
                    <i class="fas fa-camera"></i>
                    <p>Aucune publication disponible pour le moment.</p>
                </div>
            <?php else: ?>
                <div class="posts-grid">
                    <?php foreach ($posts as $post): 
                        // Construction DIRECTE des URLs (comme dans test_media.php)
                        $media_url = POSTS_URL . $post['media_path'];
                        $ext = strtolower(pathinfo($post['media_path'], PATHINFO_EXTENSION));
                        $is_video = in_array($ext, ['mp4', 'webm', 'avi', 'mov', 'mkv']);
                        $profile_url = PROFILE_PICS_URL . ($post['profile_pic'] ?? 'default_traiteur.jpg');
                    ?>
                        <div class="post-card">
                            <?php if ($is_video): ?>
                                <video src="<?= $media_url ?>" class="media" controls></video>
                            <?php else: ?>
                                <img src="<?= $media_url ?>" class="media" alt="Publication">
                            <?php endif; ?>
                            <div class="post-body">
                                <div class="traiteur-info">
                                    <img src="<?= $profile_url ?>" alt="">
                                    <div>
                                        <h4><?= htmlspecialchars($post['service_name']) ?></h4>
                                        <span class="date"><?= date('d/m/Y H:i', strtotime($post['created_at'])) ?></span>
                                    </div>
                                </div>
                                <?php if (!empty($post['caption'])): ?>
                                    <p class="caption"><?= htmlspecialchars($post['caption']) ?></p>
                                <?php endif; ?>
                                <p class="likes"><i class="fas fa-heart"></i> <?= $post['likes_count'] ?> likes</p>
                                <a href="view_traiteur.php?id=<?= $post['traiteur_id'] ?>" class="btn-profile">Voir le profil du traiteur →</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?= $page - 1 ?>"><i class="fas fa-chevron-left"></i> Précédent</a>
                        <?php else: ?>
                            <span class="disabled"><i class="fas fa-chevron-left"></i> Précédent</span>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <a href="?page=<?= $i ?>" class="<?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
                        <?php endfor; ?>

                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?= $page + 1 ?>">Suivant <i class="fas fa-chevron-right"></i></a>
                        <?php else: ?>
                            <span class="disabled">Suivant <i class="fas fa-chevron-right"></i></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</main>

<script>
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>