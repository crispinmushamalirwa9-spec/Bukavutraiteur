-- --------------------------------------------------------
-- Base de données : `bukavu_traiteur`
-- --------------------------------------------------------

CREATE DATABASE IF NOT EXISTS `bukavu_traiteur` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `bukavu_traiteur`;

-- --------------------------------------------------------
-- Table `users` (Tous les comptes : admin, traiteur, client)
-- --------------------------------------------------------
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL UNIQUE,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','traiteur','client') NOT NULL,
  `status` enum('actif','inactif','bloque') DEFAULT 'actif',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `admin_profiles` (Paramètres Admin)
-- --------------------------------------------------------
CREATE TABLE `admin_profiles` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `traiteur_profiles` (Infos des traiteurs - UNIQUEMENT Bukavu)
-- --------------------------------------------------------
CREATE TABLE `traiteur_profiles` (
  `user_id` int(11) NOT NULL,
  `service_name` varchar(150) NOT NULL UNIQUE, -- Le nom affiché au client
  `address` text NOT NULL,
  `city` varchar(50) DEFAULT 'Bukavu', -- Bloqué sur Bukavu
  `description` text,
  `profile_pic` varchar(255) DEFAULT 'default_traiteur.jpg',
  `experience_years` int(11) DEFAULT 0,
  `total_likes` int(11) DEFAULT 0,
  `total_posts` int(11) DEFAULT 0,
  `ranking_score` decimal(10,2) DEFAULT 0.00, -- Calculé automatiquement
  `loyalty_score` decimal(10,2) DEFAULT 0.00, -- Fidélisation
  `is_verified` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `service_types` (Types de cérémonie : Mariage, Anniversaire...)
-- --------------------------------------------------------
CREATE TABLE `service_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL UNIQUE,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `traiteur_services` (Relation traiteur <-> types de service)
-- --------------------------------------------------------
CREATE TABLE `traiteur_services` (
  `traiteur_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  PRIMARY KEY (`traiteur_id`,`service_id`),
  FOREIGN KEY (`traiteur_id`) REFERENCES `traiteur_profiles`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`service_id`) REFERENCES `service_types`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `client_profiles` (Infos des clients)
-- --------------------------------------------------------
CREATE TABLE `client_profiles` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT 'default_client.jpg',
  `last_connection` datetime DEFAULT NULL, -- Pour voir les actifs
  PRIMARY KEY (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `temp_codes` (Code à 5 chiffres généré par l'admin pour les traiteurs)
-- --------------------------------------------------------
CREATE TABLE `temp_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(5) NOT NULL,
  `is_used` tinyint(1) DEFAULT 0,
  `created_by` int(11) NOT NULL, -- ID de l'admin
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_code` (`code`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `posts` (Publications photo/vidéo des traiteurs)
-- --------------------------------------------------------
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `traiteur_id` int(11) NOT NULL,
  `media_path` varchar(255) NOT NULL, -- Chemin de la photo/vidéo
  `caption` text, -- Ce que le traiteur écrit en bas
  `likes_count` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`traiteur_id`) REFERENCES `traiteur_profiles`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `post_likes` (Évite les doublons de likes)
-- --------------------------------------------------------
CREATE TABLE `post_likes` (
  `post_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL, -- Un client like
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`,`client_id`),
  FOREIGN KEY (`post_id`) REFERENCES `posts`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`client_id`) REFERENCES `client_profiles`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `orders` (Commandes clients)
-- --------------------------------------------------------
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `traiteur_id` int(11) NOT NULL,
  `service_type_id` int(11) DEFAULT NULL, -- Quel type de cérémonie
  `ceremony_date` date NOT NULL,
  `description` text NOT NULL, -- Détails de la commande
  `status` enum('en_attente','en_cours','termine','refuse') DEFAULT 'en_attente',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`client_id`) REFERENCES `client_profiles`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`traiteur_id`) REFERENCES `traiteur_profiles`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`service_type_id`) REFERENCES `service_types`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `reviews` (Avis positifs ou négatifs des clients)
-- --------------------------------------------------------
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `traiteur_id` int(11) NOT NULL,
  `rating` enum('positif','negatif') NOT NULL,
  `comment` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`client_id`) REFERENCES `client_profiles`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`traiteur_id`) REFERENCES `traiteur_profiles`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `reports` (Signalements d'un client par un traiteur)
-- --------------------------------------------------------
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `traiteur_id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_report` (`client_id`,`traiteur_id`), -- Un traiteur ne peut signaler qu'une fois
  FOREIGN KEY (`client_id`) REFERENCES `client_profiles`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`traiteur_id`) REFERENCES `traiteur_profiles`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table `notifications` (Pour l'admin, les traiteurs et les clients)
-- --------------------------------------------------------
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Insérer un admin par défaut (email: admin@bukavu.com / mot de passe: Admin123!)
-- --------------------------------------------------------
INSERT INTO `users` (`email`, `password_hash`, `role`) VALUES
('admin@bukavu.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
-- (Le hash correspond à "Admin123!" en Bcrypt)

INSERT INTO `admin_profiles` (`user_id`, `full_name`) VALUES (1, 'Super Admin Bukavu');

-- --------------------------------------------------------
-- Insérer des types de services de base
-- --------------------------------------------------------
INSERT INTO `service_types` (`name`) VALUES
('Mariage'),
('Anniversaire'),
('Enterrement / Veillée'),
('Fiançailles'),
('Cérémonie Religieuse'),
('Réception d\'entreprise'),
('Fête de fin d\'année');