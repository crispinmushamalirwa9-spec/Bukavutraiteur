<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "1. Avant inclusion de config.php<br>";
require_once __DIR__ . '/../config/config.php';
echo "2. Après inclusion de config.php<br>";

if (isset($pdo)) {
    echo "3. Connexion PDO OK<br>";
} else {
    echo "3. PDO non défini<br>";
}

echo "4. SITE_URL = " . SITE_URL . "<br>";
echo "5. Fin du test";