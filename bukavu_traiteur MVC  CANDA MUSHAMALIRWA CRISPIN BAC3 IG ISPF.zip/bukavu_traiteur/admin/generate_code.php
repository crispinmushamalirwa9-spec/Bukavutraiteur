<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'admin') {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';
$generated_code = '';

// --- GÉNÉRER UN NOUVEAU CODE ---
if (isset($_POST['generate'])) {
    $code = generate_traiteur_code($pdo, $user_id);
    if ($code) {
        $generated_code = $code;
        $success = '✅ Code généré avec succès : <strong>' . $code . '</strong>';
        add_notification($pdo, $user_id, "Code traiteur généré : $code");
    } else {
        $error = '❌ Erreur lors de la génération du code.';
    }
}

// --- SUPPRIMER UN CODE ---
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $code_id = (int)$_GET['delete'];
    $check = $pdo->prepare("SELECT id FROM temp_codes WHERE id = ? AND is_used = 0");
    $check->execute([$code_id]);
    if ($check->rowCount() > 0) {
        $delete = $pdo->prepare("DELETE FROM temp_codes WHERE id = ?");
        $delete->execute([$code_id]);
        header('Location: generate_code.php?msg=deleted');
        exit;
    }
}

// --- RÉCUPÉRER LA LISTE DES CODES ---
$stmt = $pdo->query("
    SELECT id, code, is_used, created_at, created_by
    FROM temp_codes
    ORDER BY created_at DESC
");
$codes = $stmt->fetchAll();

$msg = '';
if (isset($_GET['msg']) && $_GET['msg'] === 'deleted') {
    $msg = '✅ Code supprimé avec succès.';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Générer des codes - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }
        .btn {
            display: inline-block;
            padding: 10px 28px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 1rem;
            border: none;
            cursor: pointer;
            transition: 0.3s;
        }
        .btn-primary { background: #2e7d32; color: #fff; }
        .btn-primary:hover { background: #1a3c2a; transform: translateY(-2px); }
        .btn-danger { background: #c62828; color: #fff; }
        .btn-danger:hover { background: #b71c1c; }
        .btn-danger-small {
            background: rgba(244, 67, 54, 0.2);
            color: #ffcdd2;
            padding: 3px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            border: none;
            cursor: pointer;
            transition: 0.3s;
        }
        .btn-danger-small:hover { background: rgba(244, 67, 54, 0.4); }

        .alert {
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        .alert-success {
            background: rgba(46, 125, 50, 0.2);
            border-color: #2e7d32;
            color: #a5d6a7;
        }
        .alert-danger {
            background: rgba(244, 67, 54, 0.2);
            border-color: #f44336;
            color: #ffcdd2;
        }

        .code-display {
            background: rgba(255,255,255,0.05);
            border-radius: 16px;
            padding: 30px;
            text-align: center;
            margin: 20px 0;
            border: 2px dashed rgba(165, 214, 167, 0.3);
        }
        .code-display .code {
            font-size: 4rem;
            font-weight: 900;
            letter-spacing: 15px;
            color: #a5d6a7;
            font-family: 'Courier New', monospace;
        }
        .code-display .copy-btn {
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            color: #fff;
            padding: 8px 24px;
            border-radius: 30px;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 15px;
        }
        .code-display .copy-btn:hover { background: rgba(255,255,255,0.2); }

        .table-wrap {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }
        th {
            text-align: left;
            padding: 12px 12px;
            color: rgba(255,255,255,0.7);
            font-weight: 600;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        td {
            padding: 12px 12px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            vertical-align: middle;
        }
        .badge {
            display: inline-block;
            padding: 3px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-success { background: rgba(46, 125, 50, 0.3); color: #a5d6a7; }
        .badge-danger { background: rgba(244, 67, 54, 0.3); color: #ffcdd2; }
        .badge-warning { background: rgba(255, 193, 7, 0.3); color: #ffe082; }
        .code-font {
            font-family: 'Courier New', monospace;
            font-weight: 700;
            font-size: 1.2rem;
            letter-spacing: 3px;
        }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
            .code-display .code { font-size: 2.5rem; letter-spacing: 8px; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="<?= SITE_URL ?>"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_traiteurs.php">Traiteurs</a></li>
                <li><a href="manage_clients.php">Clients</a></li>
                <li><a href="generate_code.php">Code</a></li>
                <li><a href="send_notification.php">Notifications</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <!-- Section génération -->
        <div class="section">
            <h2><i class="fas fa-key"></i> Générer un code d'invitation</h2>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            <?php if ($msg): ?>
                <div class="alert alert-success"><?= $msg ?></div>
            <?php endif; ?>

            <p style="color:rgba(255,255,255,0.7); margin-bottom:20px;">
                <i class="fas fa-info-circle"></i> 
                Générez un code à 5 chiffres unique pour permettre à un traiteur de s'inscrire.
                Chaque code ne peut être utilisé qu'une seule fois.
            </p>

            <form method="POST">
                <button type="submit" name="generate" class="btn btn-primary">
                    <i class="fas fa-sync-alt"></i> Générer un nouveau code
                </button>
            </form>

            <?php if ($generated_code): ?>
                <div class="code-display">
                    <div class="code"><?= $generated_code ?></div>
                    <button class="copy-btn" onclick="copyCode('<?= $generated_code ?>')">
                        <i class="fas fa-copy"></i> Copier le code
                    </button>
                    <p style="color:rgba(255,255,255,0.5); font-size:0.9rem; margin-top:10px;">
                        Donnez ce code au traiteur pour qu'il puisse s'inscrire.
                    </p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Liste des codes générés -->
        <div class="section">
            <h2><i class="fas fa-list"></i> Codes générés</h2>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Statut</th>
                            <th>Date de création</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($codes)): ?>
                            <tr><td colspan="4" style="text-align:center; color:rgba(255,255,255,0.4); padding:30px;">Aucun code généré.</td></tr>
                        <?php else: ?>
                            <?php foreach ($codes as $c): ?>
                                <tr>
                                    <td class="code-font"><?= htmlspecialchars($c['code']) ?></td>
                                    <td>
                                        <?php if ($c['is_used'] == 1): ?>
                                            <span class="badge badge-danger"><i class="fas fa-check"></i> Utilisé</span>
                                        <?php else: ?>
                                            <span class="badge badge-success"><i class="fas fa-clock"></i> Disponible</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('d/m/Y H:i', strtotime($c['created_at'])) ?></td>
                                    <td>
                                        <?php if ($c['is_used'] == 0): ?>
                                            <a href="?delete=<?= $c['id'] ?>" class="btn-danger-small" onclick="return confirm('Supprimer ce code ?')">
                                                <i class="fas fa-trash"></i> Supprimer
                                            </a>
                                        <?php else: ?>
                                            <span style="color:rgba(255,255,255,0.3); font-size:0.8rem;">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

<script>
    function copyCode(code) {
        navigator.clipboard.writeText(code).then(() => {
            alert('Code copié dans le presse-papier !');
        }).catch(() => {
            // Fallback pour les navigateurs anciens
            const input = document.createElement('input');
            input.value = code;
            document.body.appendChild(input);
            input.select();
            document.execCommand('copy');
            document.body.removeChild(input);
            alert('Code copié dans le presse-papier !');
        });
    }

    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>