<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

// Vérification de la connexion PDO
if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

// Sécurisation des sessions
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'admin') {
    header('Location: login.php');
    exit;
}

// --- TRAITEMENT DES ACTIONS (activer / désactiver) ---
if (isset($_GET['action']) && isset($_GET['id'])) {
    $traiteur_id = (int)$_GET['id'];
    $action = $_GET['action'];
    $new_status = ($action === 'activate') ? 'actif' : 'inactif';

    // Vérifier que l'utilisateur est bien un traiteur
    $check = $pdo->prepare("SELECT id FROM users WHERE id = ? AND role = 'traiteur'");
    $check->execute([$traiteur_id]);
    if ($check->rowCount() > 0) {
        $update = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        $update->execute([$new_status, $traiteur_id]);
        // Redirection pour éviter la re-soumission
        header('Location: manage_traiteurs.php?msg=success');
        exit;
    }
}

// --- RÉCUPÉRATION DE LA LISTE DES TRAITEURS ---
$stmt = $pdo->query("
    SELECT u.id, u.email, u.status, u.created_at,
           tp.service_name, tp.address, tp.profile_pic, tp.ranking_score,
           (SELECT COUNT(*) FROM orders WHERE traiteur_id = u.id) as total_orders
    FROM users u
    JOIN traiteur_profiles tp ON u.id = tp.user_id
    WHERE u.role = 'traiteur'
    ORDER BY tp.ranking_score DESC
");
$traiteurs = $stmt->fetchAll();

// Vérifier si un message de succès est passé
$msg = isset($_GET['msg']) && $_GET['msg'] === 'success' ? '✅ Statut mis à jour avec succès.' : '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer les traiteurs - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }
        .btn {
            display: inline-block;
            padding: 8px 18px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 0.85rem;
            border: none;
            cursor: pointer;
            transition: 0.3s;
        }
        .btn-primary { background: #2e7d32; color: #fff; }
        .btn-primary:hover { background: #1a3c2a; transform: translateY(-2px); }
        .btn-danger { background: #c62828; color: #fff; }
        .btn-danger:hover { background: #b71c1c; }
        .btn-success { background: #2e7d32; color: #fff; }
        .btn-success:hover { background: #1a3c2a; }
        .btn-warning { background: #f9a825; color: #1a1a2e; }
        .btn-warning:hover { background: #f57f17; }

        .table-wrap {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }
        th {
            text-align: left;
            padding: 12px 12px;
            color: rgba(255,255,255,0.7);
            font-weight: 600;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        td {
            padding: 12px 12px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            vertical-align: middle;
        }
        .badge {
            display: inline-block;
            padding: 3px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-success { background: rgba(46, 125, 50, 0.3); color: #a5d6a7; }
        .badge-danger { background: rgba(244, 67, 54, 0.3); color: #ffcdd2; }
        .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            background: rgba(255,255,255,0.1);
        }
        .alert-success {
            background: rgba(46, 125, 50, 0.2);
            border-left: 4px solid #2e7d32;
            padding: 12px 16px;
            border-radius: 12px;
            color: #a5d6a7;
            margin-bottom: 20px;
        }
        .actions a {
            margin: 0 4px;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.8rem;
            font-weight: 600;
            display: inline-block;
            transition: 0.3s;
        }
        .actions a:hover { opacity: 0.8; }
        .link-code {
            background: #f9a825;
            color: #1a1a2e;
            padding: 8px 20px;
            border-radius: 30px;
            font-weight: 600;
        }
        .link-code:hover { background: #f57f17; }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
            table { font-size: 0.85rem; }
            .actions a { padding: 4px 8px; font-size: 0.7rem; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="<?= SITE_URL ?>"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
         <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_traiteurs.php">Traiteurs</a></li>
                <li><a href="manage_clients.php">Clients</a></li>
                <li><a href="generate_code.php">Code</a></li>
                <li><a href="send_notification.php">Notifications</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-user-shield"></i> Admin
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <div class="section">
            <h2><i class="fas fa-users-cog"></i> Gestion des traiteurs</h2>

            <?php if ($msg): ?>
                <div class="alert-success"><?= $msg ?></div>
            <?php endif; ?>

            <p style="margin-bottom:20px;">
                <a href="generate_code.php" class="link-code"><i class="fas fa-key"></i> Générer un code d'invitation</a>
            </p>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Service</th>
                            <th>Email</th>
                            <th>Adresse</th>
                            <th>Score</th>
                            <th>Commandes</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($traiteurs)): ?>
                            <tr><td colspan="8" style="text-align:center; color:rgba(255,255,255,0.4); padding:30px;">Aucun traiteur inscrit.</td></tr>
                        <?php else: ?>
                            <?php foreach ($traiteurs as $t): ?>
                                <tr>
                                    <td>
                                        <img src="<?= SITE_URL ?>assets/uploads/profiles/<?= htmlspecialchars($t['profile_pic'] ?? 'default_traiteur.jpg') ?>" class="avatar" alt="">
                                    </td>
                                    <td><strong><?= htmlspecialchars($t['service_name']) ?></strong></td>
                                    <td><?= htmlspecialchars($t['email']) ?></td>
                                    <td><?= htmlspecialchars($t['address'] ?? 'Non renseigné') ?></td>
                                    <td><?= number_format($t['ranking_score'] ?? 0, 1) ?></td>
                                    <td><?= $t['total_orders'] ?></td>
                                    <td>
                                        <span class="badge <?= $t['status'] === 'actif' ? 'badge-success' : 'badge-danger' ?>">
                                            <?= $t['status'] ?>
                                        </span>
                                    </td>
                                    <td class="actions">
                                        <?php if ($t['status'] === 'actif'): ?>
                                            <a href="?action=deactivate&id=<?= $t['id'] ?>" class="btn btn-danger" onclick="return confirm('Bloquer ce traiteur ?')">Bloquer</a>
                                        <?php else: ?>
                                            <a href="?action=activate&id=<?= $t['id'] ?>" class="btn btn-success" onclick="return confirm('Activer ce traiteur ?')">Activer</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

<script>
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>