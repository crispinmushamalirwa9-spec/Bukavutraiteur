<?php
// /admin/logout.php
session_start();
session_destroy();

// Redirection vers la racine (index.php)
header('Location: ../index.php?logout=success');
exit;