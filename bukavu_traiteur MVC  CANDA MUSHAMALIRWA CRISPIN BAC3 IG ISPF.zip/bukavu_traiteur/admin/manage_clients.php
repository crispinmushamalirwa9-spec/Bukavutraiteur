<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/config.php';

if (!isset($pdo)) {
    die('Erreur de connexion à la base de données.');
}

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

if (!$user_id || $user_role !== 'admin') {
    header('Location: login.php');
    exit;
}

// --- SUPPRESSION D'UN CLIENT ---
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $client_id = (int)$_GET['delete'];
    $check = $pdo->prepare("SELECT id FROM users WHERE id = ? AND role = 'client'");
    $check->execute([$client_id]);
    if ($check->rowCount() > 0) {
        $delete = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $delete->execute([$client_id]);
        header('Location: manage_clients.php?msg=deleted');
        exit;
    }
}

// --- ENVOI DE NOTIFICATION (via AJAX ou POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['notify_client'])) {
    $client_id = (int)$_POST['client_id'];
    $message = trim($_POST['message']);
    if (!empty($message) && $client_id > 0) {
        add_notification($pdo, $client_id, $message);
        header('Location: manage_clients.php?msg=notified');
        exit;
    }
}

// --- RÉCUPÉRATION DE LA LISTE DES CLIENTS ---
$stmt = $pdo->query("
    SELECT u.id, u.email, u.status, u.created_at,
           cp.full_name, cp.phone, cp.last_connection, cp.profile_pic,
           (SELECT COUNT(*) FROM reports WHERE client_id = u.id) as nb_reports
    FROM users u
    JOIN client_profiles cp ON u.id = cp.user_id
    WHERE u.role = 'client'
    ORDER BY cp.last_connection DESC
");
$clients = $stmt->fetchAll();

$now = new DateTime();
$msg = '';
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'deleted') $msg = '✅ Client supprimé avec succès.';
    if ($_GET['msg'] === 'notified') $msg = '✅ Notification envoyée.';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer les clients - BukavuTraiteur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.5;
            background: #0f0f0f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('../assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 10px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 1.8rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i { color: #a5d6a7; margin-right: 8px; }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 6px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            font-size: 0.9rem;
        }
        .nav-menu li a:hover { background: rgba(255,255,255,0.15); color: #fff; }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            padding: 6px 18px;
        }
        .nav-menu li a.btn-outline:hover { background: #fff; color: #1a3c2a; border-color: #fff; }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-info i { color: #a5d6a7; margin-right: 6px; }

        .main-content {
            flex: 1;
            padding: 100px 0 40px;
        }
        .section {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .section h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(165, 214, 167, 0.3);
            padding-bottom: 12px;
        }
        .alert-success {
            background: rgba(46, 125, 50, 0.2);
            border-left: 4px solid #2e7d32;
            padding: 12px 16px;
            border-radius: 12px;
            color: #a5d6a7;
            margin-bottom: 20px;
        }
        .table-wrap {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }
        th {
            text-align: left;
            padding: 12px 12px;
            color: rgba(255,255,255,0.7);
            font-weight: 600;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        td {
            padding: 12px 12px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            vertical-align: middle;
        }
        .badge {
            display: inline-block;
            padding: 3px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-success { background: rgba(46, 125, 50, 0.3); color: #a5d6a7; }
        .badge-danger { background: rgba(244, 67, 54, 0.3); color: #ffcdd2; }
        .badge-warning { background: rgba(255, 193, 7, 0.3); color: #ffe082; }
        .badge-report { background: rgba(244, 67, 54, 0.2); color: #ffcdd2; padding: 2px 10px; border-radius: 30px; }
        .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            background: rgba(255,255,255,0.1);
        }
        .btn {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 0.8rem;
            border: none;
            cursor: pointer;
            transition: 0.3s;
        }
        .btn-danger { background: #c62828; color: #fff; }
        .btn-danger:hover { background: #b71c1c; }
        .btn-primary { background: #2e7d32; color: #fff; }
        .btn-primary:hover { background: #1a3c2a; }
        .btn-info { background: #0d47a1; color: #fff; }
        .btn-info:hover { background: #0a3a7a; }
        .actions a, .actions button {
            margin: 0 4px;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            display: inline-block;
        }
        .actions a:hover, .actions button:hover { opacity: 0.8; }

        .main-footer {
            background: rgba(0,0,0,0.35);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 30px 0 15px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 30px;
            border-radius: 24px 24px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }
        .main-footer h4 { color: #fff; font-weight: 700; font-size: 1rem; margin-bottom: 10px; }
        .main-footer ul { list-style: none; padding: 0; }
        .main-footer ul li { margin-bottom: 4px; font-size: 0.9rem; }
        .main-footer ul li a { color: rgba(255,255,255,0.7); transition: 0.3s; }
        .main-footer ul li a:hover { color: #a5d6a7; }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 12px;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255,255,255,0.4);
        }

        @media (max-width: 768px) {
            .main-header .container { flex-direction: column; gap: 8px; }
            .nav-menu { justify-content: center; }
            .section { padding: 20px; }
            table { font-size: 0.85rem; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="<?= SITE_URL ?>"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_traiteurs.php">Traiteurs</a></li>
                <li><a href="manage_clients.php">Clients</a></li>
                <li><a href="generate_code.php">Code</a></li>
                <li><a href="send_notification.php">Notifications</a></li>
                <li><a href="settings.php">Paramètres</a></li>
                <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
            </ul>
        </nav>
        <div class="user-info">
            <i class="fas fa-user-shield"></i> Admin
        </div>
    </div>
</header>

<!-- CONTENU PRINCIPAL -->
<main class="main-content">
    <div class="container">

        <div class="section">
            <h2><i class="fas fa-user-friends"></i> Gestion des clients</h2>

            <?php if ($msg): ?>
                <div class="alert-success"><?= $msg ?></div>
            <?php endif; ?>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Téléphone</th>
                            <th>Dernière connexion</th>
                            <th>Signalements</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($clients)): ?>
                            <tr><td colspan="8" style="text-align:center; color:rgba(255,255,255,0.4); padding:30px;">Aucun client inscrit.</td></tr>
                        <?php else: ?>
                            <?php foreach ($clients as $c): 
                                $last_conn = $c['last_connection'] ? new DateTime($c['last_connection']) : null;
                                $inactive_days = $last_conn ? $now->diff($last_conn)->days : 999;
                                $is_active = ($inactive_days < 30);
                                $status_label = $c['status'] === 'actif' ? ($is_active ? 'Actif' : 'Inactif') : $c['status'];
                                $status_badge = ($c['status'] === 'actif' && $is_active) ? 'badge-success' : 'badge-danger';
                            ?>
                                <tr>
                                    <td>
                                        <img src="<?= SITE_URL ?>assets/uploads/profiles/<?= htmlspecialchars($c['profile_pic'] ?? 'default_client.jpg') ?>" class="avatar" alt="">
                                    </td>
                                    <td><strong><?= htmlspecialchars($c['full_name']) ?></strong></td>
                                    <td><?= htmlspecialchars($c['email']) ?></td>
                                    <td><?= htmlspecialchars($c['phone'] ?? 'Non renseigné') ?></td>
                                    <td>
                                        <?= $last_conn ? $last_conn->format('d/m/Y H:i') : 'Jamais' ?>
                                        <?php if ($c['status'] === 'actif' && !$is_active): ?>
                                            <span class="badge badge-warning">Inactif</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($c['nb_reports'] > 0): ?>
                                            <span class="badge-report"><i class="fas fa-flag"></i> <?= $c['nb_reports'] ?></span>
                                        <?php else: ?>
                                            <span style="color:rgba(255,255,255,0.3);">0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?= $status_badge ?>"><?= $status_label ?></span>
                                    </td>
                                    <td class="actions">
                                        <a href="?delete=<?= $c['id'] ?>" class="btn btn-danger" onclick="return confirm('Supprimer définitivement ce client ?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        <button class="btn btn-info" onclick="notifyClient(<?= $c['id'] ?>, '<?= htmlspecialchars($c['full_name']) ?>')">
                                            <i class="fas fa-bell"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

<!-- Script pour la notification via AJAX (prompt) -->
<script>
    function notifyClient(id, name) {
        const msg = prompt(`Envoyer une notification à ${name} :`, "Bonjour, nous avons une nouvelle offre pour vous !");
        if (msg !== null && msg.trim() !== '') {
            // Envoyer via formulaire POST caché
            var form = document.createElement('form');
            form.method = 'POST';
            form.action = '';
            var input1 = document.createElement('input');
            input1.type = 'hidden';
            input1.name = 'notify_client';
            input1.value = '1';
            var input2 = document.createElement('input');
            input2.type = 'hidden';
            input2.name = 'client_id';
            input2.value = id;
            var input3 = document.createElement('input');
            input3.type = 'hidden';
            input3.name = 'message';
            input3.value = msg;
            form.appendChild(input1);
            form.appendChild(input2);
            form.appendChild(input3);
            document.body.appendChild(form);
            form.submit();
        }
    }

    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
</script>

</body>
</html>