<?php
// /admin/register.php
require_once __DIR__ . '/../config/config.php';

// Si l'utilisateur est déjà connecté en tant qu'admin, on le redirige
if (isset($_SESSION['user_id']) && $_SESSION['user_role'] === 'admin') {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';

// Vérifier si un administrateur existe déjà dans la base de données
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'");
$admin_count = $stmt->fetchColumn();
$admin_exists = ($admin_count > 0);

// --- TRAITEMENT DU FORMULAIRE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $full_name = trim($_POST['full_name']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $token = trim($_POST['token'] ?? '');

    // 1. Vérification des champs
    if (empty($email) || empty($full_name) || empty($password)) {
        $error = 'Veuillez remplir tous les champs obligatoires.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Adresse email invalide.';
    } elseif ($password !== $confirm_password) {
        $error = 'Les mots de passe ne correspondent pas.';
    } elseif (strlen($password) < 6) {
        $error = 'Le mot de passe doit contenir au moins 6 caractères.';
    } 
    // 2. Vérification du TOKEN si un admin existe déjà (sinon, on autorise sans token pour le premier admin)
    elseif ($admin_exists && $token !== ADMIN_CREATION_TOKEN) {
        $error = '❌ Token de sécurité invalide. Vous ne pouvez pas créer un compte administrateur sans le token secret.';
    } 
    else {
        // 3. Vérifier si l'email est déjà utilisé (par n'importe quel rôle)
        $checkEmail = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $checkEmail->execute([$email]);
        if ($checkEmail->rowCount() > 0) {
            $error = 'Cet email est déjà utilisé par un autre compte.';
        } else {
            try {
                // 4. Création du compte admin
                $password_hash = password_hash($password, PASSWORD_DEFAULT);

                $pdo->beginTransaction();

                $insertUser = $pdo->prepare("INSERT INTO users (email, password_hash, role, status) VALUES (?, ?, 'admin', 'actif')");
                $insertUser->execute([$email, $password_hash]);
                $user_id = $pdo->lastInsertId();

                $insertProfile = $pdo->prepare("INSERT INTO admin_profiles (user_id, full_name) VALUES (?, ?)");
                $insertProfile->execute([$user_id, $full_name]);

                $pdo->commit();

                // Rediriger vers la page de connexion avec un message de succès
                $_SESSION['flash_message'] = '✅ Compte Administrateur créé avec succès ! Connectez-vous maintenant.';
                $_SESSION['flash_type'] = 'success';
                header('Location: login.php');
                exit;

            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Une erreur technique est survenue. Veuillez réessayer.';
                // En développement : $error = $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Créer un compte Admin - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; font-family: 'Poppins', sans-serif; padding: 20px; }
        .register-box { background: white; padding: 40px 35px; border-radius: 24px; box-shadow: 0 20px 60px rgba(0,0,0,0.1); width: 100%; max-width: 480px; }
        .register-box h1 { text-align: center; color: #1a1a2e; margin-bottom: 5px; }
        .register-box h1 i { color: #f7c948; }
        .register-box .subtitle { text-align: center; color: #888; margin-bottom: 25px; font-size: 0.95rem; }
        .register-box label { font-weight: 600; color: #333; display: block; margin-bottom: 5px; font-size: 0.9rem; }
        .register-box input { width: 100%; padding: 12px 15px; border: 2px solid #e0e0e0; border-radius: 12px; margin-bottom: 18px; font-size: 1rem; transition: 0.3s; box-sizing: border-box; }
        .register-box input:focus { border-color: #f7c948; outline: none; box-shadow: 0 0 0 4px rgba(247, 201, 72, 0.15); }
        .register-box .alert { padding: 14px; border-radius: 12px; margin-bottom: 20px; border-left: 4px solid; }
        .register-box .alert-danger { background: #ffebee; color: #b71c1c; border-color: #f44336; }
        .register-box .alert-success { background: #e8f5e9; color: #1e5e2b; border-color: #4caf50; }
        .register-box .info-box { background: #fff8e1; padding: 15px; border-radius: 12px; border-left: 4px solid #f7c948; margin-bottom: 20px; font-size: 0.9rem; color: #5d4a1e; }
        .register-box button { background: #1a1a2e; color: white; border: none; padding: 15px; width: 100%; border-radius: 14px; font-size: 1.1rem; font-weight: 700; cursor: pointer; transition: 0.3s; }
        .register-box button:hover { background: #f7c948; color: #1a1a2e; }
        .register-box .links { text-align: center; margin-top: 20px; }
        .register-box .links a { color: #888; text-decoration: none; }
        .register-box .links a:hover { color: #1a1a2e; }
    </style>
</head>
<body>
    <div class="register-box">
        <h1><i class="fas fa-user-shield"></i> Admin</h1>
        <p class="subtitle">Créer un compte administrateur</p>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <!-- Informations sur la sécurité -->
        <?php if ($admin_exists): ?>
            <div class="info-box">
                <i class="fas fa-lock"></i> 
                Un administrateur existe déjà sur cette plateforme. 
                <strong>Le token de sécurité est requis</strong> pour créer un compte supplémentaire.
                <?php if (defined('ADMIN_CREATION_TOKEN')): ?>
                    <br><small style="color:#888;">(Le token est défini dans <strong>config/constants.php</strong>)</small>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="info-box">
                <i class="fas fa-info-circle"></i> 
                <strong>Aucun administrateur n'est encore enregistré.</strong> 
                Vous pouvez créer le premier compte admin sans token. 
                <br><small>(Après cette création, le token sera obligatoire pour de nouveaux admins)</small>
            </div>
        <?php endif; ?>

        <form method="POST">
            <label>Nom complet <span style="color:#e74c3c;">*</span></label>
            <input type="text" name="full_name" placeholder="Ex: Jean Admin" required>

            <label>Email <span style="color:#e74c3c;">*</span></label>
            <input type="email" name="email" placeholder="admin@bukavu.com" required>

            <label>Mot de passe <span style="color:#e74c3c;">*</span> (min 6 caractères)</label>
            <input type="password" name="password" placeholder="••••••••" minlength="6" required>

            <label>Confirmer le mot de passe <span style="color:#e74c3c;">*</span></label>
            <input type="password" name="confirm_password" placeholder="••••••••" required>

            <!-- Champ token caché si c'est le premier admin, sinon visible -->
            <?php if ($admin_exists): ?>
                <label>Token de sécurité <span style="color:#e74c3c;">*</span></label>
                <input type="text" name="token" placeholder="Entrez le token secret" required>
            <?php else: ?>
                <!-- On le passe en hidden pour les besoins du formulaire sans embêter l'utilisateur -->
                <input type="hidden" name="token" value="<?= ADMIN_CREATION_TOKEN ?>">
            <?php endif; ?>

            <button type="submit"><i class="fas fa-user-plus"></i> Créer le compte administrateur</button>
        </form>

        <div class="links">
            <a href="login.php"><i class="fas fa-arrow-left"></i> Retour à la connexion</a>
            <span style="color:#ddd; margin:0 10px;">|</span>
            <a href="<?= SITE_URL ?>">Accueil</a>
        </div>
    </div>
</body>
</html>