<?php
// /index.php
require_once __DIR__ . '/config/config.php';

$services = get_all_service_types($pdo);
$top_traiteurs = get_top_traiteurs($pdo, 6);

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;
$user_email = isset($_SESSION['user_email']) ? $_SESSION['user_email'] : null;

$page_title = 'BukavuTraiteur - Les meilleurs traiteurs de Bukavu';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        /* ========== RESET & BASE ========== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        html {
            scroll-behavior: smooth;
        }
        body {
            font-family: 'Inter', sans-serif;
            color: #fff;
            line-height: 1.6;
            overflow-x: hidden;
            background: #0f0f0f; /* fallback */
        }
        a {
            text-decoration: none;
            color: inherit;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 24px;
        }

        /* ========== FOND FIXE ========== */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            background: url('assets/images/justine.jpg') center/cover no-repeat fixed;
            background-size: cover;
            filter: brightness(0.7) saturate(1.2);
        }

        /* ========== HEADER TRANSPARENT ========== */
        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 20px 0;
            transition: all 0.4s ease;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .main-header.scrolled {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
            padding: 12px 0;
        }
        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo a {
            font-size: 2rem;
            font-weight: 900;
            color: #fff;
            letter-spacing: -0.5px;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .logo a i {
            color: #a5d6a7;
            margin-right: 10px;
        }
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-menu li a {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 50px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            letter-spacing: 0.3px;
            text-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        .nav-menu li a:hover {
            background: rgba(255,255,255,0.15);
            color: #fff;
        }
        .nav-menu li a.btn-outline {
            border: 2px solid rgba(255,255,255,0.6);
            color: #fff;
            padding: 8px 22px;
        }
        .nav-menu li a.btn-outline:hover {
            background: #fff;
            color: #1a3c2a;
            border-color: #fff;
        }
        .nav-menu li a.btn-primary {
            background: #2e7d32;
            color: #fff;
            box-shadow: 0 4px 15px rgba(46, 125, 50, 0.4);
        }
        .nav-menu li a.btn-primary:hover {
            background: #1a3c2a;
            transform: translateY(-2px);
        }
        .user-info {
            color: #fff;
            font-weight: 600;
            font-size: 0.95rem;
            text-shadow: 0 2px 8px rgba(0,0,0,0.3);
        }
        .user-info i {
            color: #a5d6a7;
            margin-right: 6px;
        }

        /* ========== HERO (premier écran) ========== */
        .hero {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 140px 20px 80px;
            color: #fff;
            z-index: 1;
        }
        .hero-content {
            max-width: 900px;
            animation: fadeUp 1.2s ease-out;
            text-shadow: 0 4px 30px rgba(0,0,0,0.4);
        }
        .hero-content .badge {
            display: inline-block;
            background: rgba(46, 125, 50, 0.5);
            backdrop-filter: blur(4px);
            padding: 6px 20px;
            border-radius: 50px;
            font-size: 0.9rem;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 20px;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .hero-content h1 {
            font-size: 4.5rem;
            font-weight: 900;
            line-height: 1.1;
            margin-bottom: 20px;
        }
        .hero-content h1 span {
            color: #a5d6a7;
            border-bottom: 4px solid #2e7d32;
            padding-bottom: 6px;
        }
        .hero-content p {
            font-size: 1.3rem;
            opacity: 0.95;
            max-width: 600px;
            margin: 0 auto 40px;
            font-weight: 300;
        }
        .hero-buttons {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 16px;
        }
        .btn {
            display: inline-block;
            padding: 14px 42px;
            border-radius: 60px;
            font-weight: 700;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        .btn-primary {
            background: #2e7d32;
            color: #fff;
            box-shadow: 0 8px 30px rgba(46, 125, 50, 0.4);
        }
        .btn-primary:hover {
            background: #1a3c2a;
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(26, 60, 42, 0.5);
        }
        .btn-outline-light {
            background: rgba(255,255,255,0.1);
            color: #fff;
            border: 2px solid rgba(255,255,255,0.6);
            backdrop-filter: blur(4px);
        }
        .btn-outline-light:hover {
            background: rgba(255,255,255,0.2);
            transform: translateY(-4px);
        }
        @keyframes fadeUp {
            0% { opacity: 0; transform: translateY(40px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        /* ========== SECTIONS TRANSPARENTES ========== */
        .section {
            padding: 90px 0;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(4px);
            border-top: 1px solid rgba(255,255,255,0.06);
            border-bottom: 1px solid rgba(255,255,255,0.06);
            margin: 20px 0;
            border-radius: 30px;
            position: relative;
            z-index: 2;
        }
        .section-title {
            font-size: 2.8rem;
            font-weight: 800;
            margin-bottom: 12px;
            letter-spacing: -0.5px;
            color: #fff;
            text-shadow: 0 2px 20px rgba(0,0,0,0.3);
        }
        .section-title span {
            color: #a5d6a7;
        }
        .section-subtitle {
            font-size: 1.2rem;
            color: rgba(255,255,255,0.8);
            margin-bottom: 50px;
            font-weight: 300;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        /* ========== SERVICES ========== */
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 24px;
        }
        .service-card {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            padding: 30px 16px;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(255,255,255,0.15);
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
        }
        .service-card:hover {
            transform: translateY(-8px);
            background: rgba(255,255,255,0.2);
            border-color: #a5d6a7;
            box-shadow: 0 16px 48px rgba(0,0,0,0.2);
        }
        .service-card i {
            font-size: 2.8rem;
            color: #a5d6a7;
            margin-bottom: 12px;
            display: block;
        }
        .service-card h3 {
            font-size: 1.1rem;
            font-weight: 700;
            color: #fff;
        }

        /* ========== TOP TRAITEURS ========== */
        .traiteurs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 30px;
        }
        .traiteur-card {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(8px);
            border-radius: 24px;
            overflow: hidden;
            transition: all 0.3s ease;
            border: 1px solid rgba(255,255,255,0.15);
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
        }
        .traiteur-card:hover {
            transform: translateY(-8px);
            background: rgba(255,255,255,0.2);
            box-shadow: 0 16px 48px rgba(0,0,0,0.2);
            border-color: #a5d6a7;
        }
        .traiteur-card .card-img {
            width: 100%;
            height: 220px;
            object-fit: cover;
            background: rgba(0,0,0,0.3);
            display: block;
        }
        .traiteur-card .card-body {
            padding: 24px;
        }
        .traiteur-card .card-body h3 {
            font-size: 1.3rem;
            font-weight: 800;
            margin: 0 0 4px;
            color: #fff;
        }
        .traiteur-card .card-body .location {
            color: rgba(255,255,255,0.7);
            font-size: 0.9rem;
            margin-bottom: 10px;
        }
        .traiteur-card .card-body .score {
            display: inline-block;
            background: #1a3c2a;
            color: #a5d6a7;
            font-weight: 700;
            padding: 4px 16px;
            border-radius: 30px;
            font-size: 0.9rem;
            margin-bottom: 14px;
        }
        .traiteur-card .card-body .btn-view {
            display: inline-block;
            background: #2e7d32;
            color: #fff;
            padding: 10px 24px;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s;
        }
        .traiteur-card .card-body .btn-view:hover {
            background: #1a3c2a;
        }

        /* ========== WHY US ========== */
        .why-us-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }
        .why-us-item {
            text-align: center;
            padding: 20px;
            border-radius: 20px;
            background: rgba(255,255,255,0.08);
            backdrop-filter: blur(4px);
            border: 1px solid rgba(255,255,255,0.1);
            transition: 0.3s;
        }
        .why-us-item:hover {
            background: rgba(255,255,255,0.15);
        }
        .why-us-item i {
            font-size: 2.8rem;
            color: #a5d6a7;
            margin-bottom: 15px;
        }
        .why-us-item h4 {
            font-weight: 700;
            font-size: 1.2rem;
            color: #fff;
        }
        .why-us-item p {
            opacity: 0.85;
            font-size: 0.95rem;
            color: rgba(255,255,255,0.8);
        }

        /* ========== CTA BANNER ========== */
        .cta-banner {
            background: rgba(26, 60, 42, 0.6);
            backdrop-filter: blur(12px);
            border-radius: 30px;
            padding: 60px 40px;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.15);
        }
        .cta-banner h2 {
            font-size: 2.6rem;
            font-weight: 800;
            margin-bottom: 15px;
            color: #fff;
        }
        .cta-banner p {
            font-size: 1.2rem;
            opacity: 0.9;
            max-width: 600px;
            margin: 0 auto 30px;
            color: rgba(255,255,255,0.9);
        }
        .cta-banner .btn-cta {
            background: #2e7d32;
            color: #fff;
            padding: 16px 48px;
            border-radius: 60px;
            font-weight: 700;
            font-size: 1.1rem;
            transition: all 0.3s;
            box-shadow: 0 8px 30px rgba(46, 125, 50, 0.4);
            display: inline-block;
        }
        .cta-banner .btn-cta:hover {
            background: #a5d6a7;
            color: #1a3c2a;
            transform: scale(1.04);
        }
        .cta-banner .link-traiteur {
            color: #a5d6a7;
            font-weight: 600;
            margin-left: 15px;
        }
        .cta-banner .link-traiteur:hover {
            text-decoration: underline;
        }

        /* ========== FOOTER TRANSPARENT ========== */
        .main-footer {
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.8);
            padding: 60px 0 30px;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 40px;
            border-radius: 30px 30px 0 0;
        }
        .main-footer .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
            margin-bottom: 30px;
        }
        .main-footer h4 {
            color: #fff;
            font-weight: 700;
            font-size: 1.2rem;
            margin-bottom: 15px;
        }
        .main-footer ul {
            list-style: none;
            padding: 0;
        }
        .main-footer ul li {
            margin-bottom: 8px;
        }
        .main-footer ul li a {
            color: rgba(255,255,255,0.7);
            transition: color 0.3s;
        }
        .main-footer ul li a:hover {
            color: #a5d6a7;
        }
        .main-footer .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding-top: 25px;
            text-align: center;
            font-size: 0.9rem;
            color: rgba(255,255,255,0.5);
        }
        .main-footer .footer-bottom i {
            color: #a5d6a7;
        }

        /* ========== RESPONSIVE ========== */
        @media (max-width: 992px) {
            .hero-content h1 {
                font-size: 3.2rem;
            }
        }
        @media (max-width: 768px) {
            .main-header .container {
                flex-direction: column;
                gap: 12px;
            }
            .nav-menu {
                justify-content: center;
            }
            .hero-content h1 {
                font-size: 2.6rem;
            }
            .hero-content p {
                font-size: 1.1rem;
            }
            .section-title {
                font-size: 2.2rem;
            }
            .cta-banner h2 {
                font-size: 2rem;
            }
            .cta-banner {
                padding: 40px 20px;
            }
        }
        @media (max-width: 480px) {
            .hero-content h1 {
                font-size: 2rem;
            }
            .btn {
                padding: 12px 28px;
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>

<!-- ========================================================= -->
<!-- HEADER TRANSPARENT                                        -->
<!-- ========================================================= -->
<header class="main-header" id="mainHeader">
    <div class="container">
        <div class="logo">
            <a href="<?= SITE_URL ?>"><i class="fas fa-utensils"></i> BukavuTraiteur</a>
        </div>
        <nav>
            <ul class="nav-menu">
                <li><a href="<?= SITE_URL ?>">Accueil</a></li>
                <li><a href="<?= SITE_URL ?>client/browse_posts.php">Explorer</a></li>
                <?php if ($user_id): ?>
                    <?php if ($user_role === 'admin'): ?>
                        <li><a href="<?= SITE_URL ?>admin/dashboard.php">Dashboard</a></li>
                        <li><a href="<?= SITE_URL ?>admin/logout.php" class="btn-outline">Déconnexion</a></li>
                    <?php elseif ($user_role === 'traiteur'): ?>
                        <li><a href="<?= SITE_URL ?>traiteur/dashboard.php">Dashboard</a></li>
                        <li><a href="<?= SITE_URL ?>traiteur/logout.php" class="btn-outline">Déconnexion</a></li>
                    <?php elseif ($user_role === 'client'): ?>
                        <li><a href="<?= SITE_URL ?>client/dashboard.php">Dashboard</a></li>
                        <li><a href="<?= SITE_URL ?>client/logout.php" class="btn-outline">Déconnexion</a></li>
                    <?php endif; ?>
                <?php else: ?>
                    <li><a href="<?= SITE_URL ?>client/login.php" class="btn-outline">Connexion</a></li>
                    <li><a href="<?= SITE_URL ?>client/register.php" class="btn-primary">Inscription</a></li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php if ($user_id): ?>
            <div class="user-info">
                <i class="fas fa-user-circle"></i>
                <?php 
                    if ($user_role === 'traiteur') {
                        $stmt = $pdo->prepare("SELECT service_name FROM traiteur_profiles WHERE user_id = ?");
                        $stmt->execute([$user_id]);
                        echo e($stmt->fetchColumn() ?: 'Traiteur');
                    } elseif ($user_role === 'client') {
                        $stmt = $pdo->prepare("SELECT full_name FROM client_profiles WHERE user_id = ?");
                        $stmt->execute([$user_id]);
                        echo e($stmt->fetchColumn() ?: 'Client');
                    } else {
                        echo 'Admin';
                    }
                ?>
            </div>
        <?php endif; ?>
    </div>
</header>

<!-- ========================================================= -->
<!-- HERO (1er écran)                                          -->
<!-- ========================================================= -->
<section class="hero">
    <div class="hero-content">
        <div class="badge"><i class="fas fa-check-circle"></i> Traiteurs vérifiés à Bukavu</div>
        <h1>Les meilleurs traiteurs de <span>Bukavu</span></h1>
        <p>Découvrez et commandez les services traiteurs les plus réputés de la ville. Qualité, fraîcheur et savoir-faire local.</p>
        <div class="hero-buttons">
            <a href="<?= SITE_URL ?>client/browse_posts.php" class="btn btn-primary">Explorer les traiteurs</a>
            <a href="<?= SITE_URL ?>traiteur/register.php" class="btn btn-outline-light">Devenir traiteur</a>
        </div>
    </div>
</section>

<!-- ========================================================= -->
<!-- SERVICES (section transparente)                           -->
<!-- ========================================================= -->
<section class="section">
    <div class="container">
        <h2 class="section-title">Nos <span>services</span> de traiteur</h2>
        <p class="section-subtitle">Choisissez le type de cérémonie et trouvez le traiteur idéal</p>
        <div class="services-grid">
            <?php if (!empty($services)): ?>
                <?php foreach ($services as $service): 
                    $icon = 'utensils';
                    if ($service['name'] === 'Mariage') $icon = 'ring';
                    elseif ($service['name'] === 'Anniversaire') $icon = 'birthday-cake';
                    elseif ($service['name'] === 'Enterrement / Veillée') $icon = 'cross';
                    elseif ($service['name'] === 'Fiançailles') $icon = 'heart';
                    elseif ($service['name'] === 'Cérémonie Religieuse') $icon = 'church';
                ?>
                    <div class="service-card">
                        <i class="fas fa-<?= $icon ?>"></i>
                        <h3><?= e($service['name']) ?></h3>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Aucun service disponible.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- ========================================================= -->
<!-- TOP TRAITEURS (transparent)                               -->
<!-- ========================================================= -->
<section class="section">
    <div class="container">
        <h2 class="section-title">🏆 Top <span>traiteurs</span> de Bukavu</h2>
        <p class="section-subtitle">Les meilleurs selon leurs performances, avis et popularité</p>
        <div class="traiteurs-grid">
            <?php if (!empty($top_traiteurs)): ?>
                <?php foreach ($top_traiteurs as $traiteur): ?>
                    <div class="traiteur-card">
                        <img src="<?= SITE_URL ?>assets/uploads/profiles/<?= e($traiteur['profile_pic'] ?? 'default_traiteur.jpg') ?>" alt="<?= e($traiteur['service_name']) ?>" class="card-img">
                        <div class="card-body">
                            <h3><?= e($traiteur['service_name']) ?></h3>
                            <div class="location"><i class="fas fa-map-marker-alt"></i> <?= e($traiteur['address'] ?? 'Bukavu') ?></div>
                            <span class="score"><i class="fas fa-star"></i> <?= number_format($traiteur['ranking_score'] ?? 0, 1) ?></span>
                            <br>
                            <a href="<?= SITE_URL ?>client/view_traiteur.php?id=<?= $traiteur['user_id'] ?>" class="btn-view">Voir le profil</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Aucun traiteur disponible pour le moment.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- ========================================================= -->
<!-- POURQUOI NOUS (transparent)                               -->
<!-- ========================================================= -->
<section class="section">
    <div class="container">
        <h2 class="section-title">Pourquoi <span style="color:#a5d6a7;">choisir</span> BukavuTraiteur ?</h2>
        <p class="section-subtitle">Une plateforme conçue pour simplifier la mise en relation</p>
        <div class="why-us-grid">
            <div class="why-us-item">
                <i class="fas fa-check-circle"></i>
                <h4>Traiteurs vérifiés</h4>
                <p>Tous nos traiteurs sont basés à Bukavu et validés par notre équipe.</p>
            </div>
            <div class="why-us-item">
                <i class="fas fa-trophy"></i>
                <h4>Système de classement</h4>
                <p>Notez et classez les traiteurs selon les avis réels des clients.</p>
            </div>
            <div class="why-us-item">
                <i class="fas fa-credit-card"></i>
                <h4>Paiement physique</h4>
                <p>La réservation est gratuite, vous payez directement le traiteur le jour J.</p>
            </div>
            <div class="why-us-item">
                <i class="fas fa-headset"></i>
                <h4>Support local</h4>
                <p>Une équipe basée à Bukavu à votre écoute pour toute question.</p>
            </div>
        </div>
    </div>
</section>

<!-- ========================================================= -->
<!-- CTA BANNER                                                -->
<!-- ========================================================= -->
<section class="section" style="background:transparent; backdrop-filter:none; border:none; margin:0; padding:20px 0;">
    <div class="container">
        <div class="cta-banner">
            <h2>Prêt à régaler vos invités ?</h2>
            <p>Que vous soyez traiteur ou client, rejoignez la communauté BukavuTraiteur dès aujourd'hui.</p>
            <a href="<?= SITE_URL ?>client/register.php" class="btn-cta"><i class="fas fa-user-plus"></i> Créer un compte client</a>
            <a href="<?= SITE_URL ?>traiteur/register.php" class="link-traiteur">Devenir traiteur →</a>
        </div>
    </div>
</section>

<!-- ========================================================= -->
<!-- FOOTER TRANSPARENT                                        -->
<!-- ========================================================= -->
<footer class="main-footer">
    <div class="container">
        <div class="footer-grid">
            <div>
                <h4><i class="fas fa-utensils"></i> BukavuTraiteur</h4>
                <p style="color:rgba(255,255,255,0.7);">La plateforme des traiteurs de Bukavu</p>
                <p style="color:rgba(255,255,255,0.4); margin-top:8px;"><i class="fas fa-map-marker-alt"></i> Bukavu, RDC</p>
            </div>
            <div>
                <h4>Liens rapides</h4>
                <ul>
                    <li><a href="<?= SITE_URL ?>">Accueil</a></li>
                    <li><a href="<?= SITE_URL ?>client/browse_posts.php">Explorer</a></li>
                    <li><a href="<?= SITE_URL ?>client/register.php">S'inscrire (client)</a></li>
                    <li><a href="<?= SITE_URL ?>traiteur/register.php">Devenir traiteur</a></li>
                </ul>
            </div>
            <div>
                <h4>Contact</h4>
                <ul>
                    <li><i class="fas fa-envelope"></i> Justinemwangaza1@gmail.com</li>
                    <li><i class="fas fa-phone"></i> +243 993 128 065</li>
                    <li><i class="fas fa-clock"></i> Lundi - Samedi, 8h-18h</li>
                </ul>
            </div>
            <div>
                <h4>Administration</h4>
                <ul>
                    <li><a href="<?= SITE_URL ?>admin/login.php"><i class="fas fa-lock"></i> Espace Admin</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; <?= date('Y') ?> BukavuTraiteur – Tous droits réservés. <i class="fas fa-heart"></i> Réalisé avec passion à Bukavu.
        </div>
    </div>
</footer>

<!-- ========================================================= -->
<!-- SCRIPTS                                                   -->
<!-- ========================================================= -->
<script>
    // Header transparent → opaque au scroll
    window.addEventListener('scroll', function() {
        const header = document.getElementById('mainHeader');
        if (window.scrollY > 80) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Animation d'apparition des cartes au scroll
    document.addEventListener('DOMContentLoaded', function() {
        const cards = document.querySelectorAll('.service-card, .traiteur-card, .why-us-item');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
        cards.forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            card.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
            observer.observe(card);
        });
    });
</script>
</body>
</html>