-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 14 juil. 2026 à 12:34
-- Version du serveur : 8.4.7
-- Version de PHP : 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bukavu_traiteur`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin_profiles`
--

DROP TABLE IF EXISTS `admin_profiles`;
CREATE TABLE IF NOT EXISTS `admin_profiles` (
  `user_id` int NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `admin_profiles`
--

INSERT INTO `admin_profiles` (`user_id`, `full_name`, `profile_pic`) VALUES
(1, 'Super Admin Bukavu', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `client_profiles`
--

DROP TABLE IF EXISTS `client_profiles`;
CREATE TABLE IF NOT EXISTS `client_profiles` (
  `user_id` int NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT 'default_client.jpg',
  `last_connection` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `client_profiles`
--

INSERT INTO `client_profiles` (`user_id`, `full_name`, `phone`, `profile_pic`, `last_connection`) VALUES
(3, 'Justin Mwangaza', '0973052845', '6a5071410c1e7.jpg', '2026-07-13 10:17:57'),
(5, 'Justine Ntumulo', '993128065', 'default_client.jpg', '2026-07-13 13:11:10');

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `is_read`, `created_at`) VALUES
(1, 1, 'Code traiteur généré : 32818', 1, '2026-07-09 16:59:55'),
(2, 3, 'Bonjour, nous avons une nouvelle offre pour vous !', 1, '2026-07-10 05:48:03'),
(3, 3, 'Bonjour a tous et bienvenu dans notre site', 1, '2026-07-10 05:49:14'),
(4, 1, 'Notification groupée envoyée à 1 utilisateurs. Cible : all_clients', 1, '2026-07-10 05:49:14'),
(5, 2, 'bonjour a tous et bienvenu dans le site, vous ne serrez pas deçu', 1, '2026-07-10 05:50:42'),
(6, 1, 'Notification groupée envoyée à 1 utilisateurs. Cible : all_traiteurs', 1, '2026-07-10 05:50:42'),
(7, 1, 'Code traiteur généré : 12282', 1, '2026-07-10 11:09:21'),
(8, 4, 'Nouvelle commande #1 reçue de la part du client ID 3.', 1, '2026-07-10 12:12:59'),
(9, 1, 'Nouvelle commande #1 créée par le client ID 3.', 1, '2026-07-10 12:12:59'),
(10, 3, 'Votre commande #1 a été acceptée et en cours de préparation par le traiteur.', 1, '2026-07-10 12:14:42');

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `traiteur_id` int NOT NULL,
  `service_type_id` int DEFAULT NULL,
  `ceremony_date` date NOT NULL,
  `description` text NOT NULL,
  `status` enum('en_attente','en_cours','termine','refuse') DEFAULT 'en_attente',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `traiteur_id` (`traiteur_id`),
  KEY `service_type_id` (`service_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`id`, `client_id`, `traiteur_id`, `service_type_id`, `ceremony_date`, `description`, `status`, `created_at`) VALUES
(1, 3, 4, 2, '2026-07-20', 'je veux une petite commande d\'un budget de 200£ pour mon anniversaire', 'en_cours', '2026-07-10 12:12:59');

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `traiteur_id` int NOT NULL,
  `media_path` varchar(255) NOT NULL,
  `caption` text,
  `likes_count` int DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `traiteur_id` (`traiteur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `posts`
--

INSERT INTO `posts` (`id`, `traiteur_id`, `media_path`, `caption`, `likes_count`, `created_at`) VALUES
(1, 2, '6a506d620a0c6.jpg', 'Que le meilleur', 0, '2026-07-10 05:56:18'),
(2, 2, '6a507206d4dcb.jpg', 'Toujours là pour vous servir', 0, '2026-07-10 06:16:06'),
(3, 2, '6a50b5d967b51.png', 'toujours pour vous servir', 0, '2026-07-10 11:05:29'),
(4, 4, '6a50c424c5df0.jpg', 'Une nourriture de qualité', 0, '2026-07-10 12:06:28');

-- --------------------------------------------------------

--
-- Structure de la table `post_likes`
--

DROP TABLE IF EXISTS `post_likes`;
CREATE TABLE IF NOT EXISTS `post_likes` (
  `post_id` int NOT NULL,
  `client_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`,`client_id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `reports`
--

DROP TABLE IF EXISTS `reports`;
CREATE TABLE IF NOT EXISTS `reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `traiteur_id` int NOT NULL,
  `reason` text NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_report` (`client_id`,`traiteur_id`),
  KEY `traiteur_id` (`traiteur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `client_id` int NOT NULL,
  `traiteur_id` int NOT NULL,
  `rating` enum('positif','negatif') NOT NULL,
  `comment` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `client_id` (`client_id`),
  KEY `traiteur_id` (`traiteur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `service_types`
--

DROP TABLE IF EXISTS `service_types`;
CREATE TABLE IF NOT EXISTS `service_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `service_types`
--

INSERT INTO `service_types` (`id`, `name`) VALUES
(2, 'Anniversaire'),
(5, 'Cérémonie Religieuse'),
(3, 'Enterrement / Veillée'),
(7, 'Fête de fin d\'année'),
(4, 'Fiançailles'),
(1, 'Mariage'),
(6, 'Réception d\'entreprise');

-- --------------------------------------------------------

--
-- Structure de la table `temp_codes`
--

DROP TABLE IF EXISTS `temp_codes`;
CREATE TABLE IF NOT EXISTS `temp_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(5) NOT NULL,
  `is_used` tinyint(1) DEFAULT '0',
  `created_by` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_code` (`code`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `temp_codes`
--

INSERT INTO `temp_codes` (`id`, `code`, `is_used`, `created_by`, `created_at`) VALUES
(1, '32818', 1, 1, '2026-07-09 16:59:55'),
(2, '12282', 1, 1, '2026-07-10 11:09:21');

-- --------------------------------------------------------

--
-- Structure de la table `traiteur_profiles`
--

DROP TABLE IF EXISTS `traiteur_profiles`;
CREATE TABLE IF NOT EXISTS `traiteur_profiles` (
  `user_id` int NOT NULL,
  `service_name` varchar(150) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) DEFAULT 'Bukavu',
  `description` text,
  `profile_pic` varchar(255) DEFAULT 'default_traiteur.jpg',
  `experience_years` int DEFAULT '0',
  `total_likes` int DEFAULT '0',
  `total_posts` int DEFAULT '0',
  `ranking_score` decimal(10,2) DEFAULT '0.00',
  `loyalty_score` decimal(10,2) DEFAULT '0.00',
  `is_verified` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `service_name` (`service_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `traiteur_profiles`
--

INSERT INTO `traiteur_profiles` (`user_id`, `service_name`, `address`, `city`, `description`, `profile_pic`, `experience_years`, `total_likes`, `total_posts`, `ranking_score`, `loyalty_score`, `is_verified`) VALUES
(2, 'Crispin Traiteur', 'Kadutu/ buholo 4', 'Bukavu', 'j\'ai plus de 10 ans dans le travail de service traiteur et nous fournissons une nourriture de qualité', '6a50ab1a1a5df.jpg', 0, 0, 3, 4.50, 0.00, 0),
(4, 'CandaTraiteur', 'Kadutu/ buholo 3', 'Bukavu', 'Depuis 8 ans, nous accompagnons vos moments importants avec des plats faits maison et un service attentionné.', '6a50c3489d572.jpg', 0, 0, 1, 1.50, 0.00, 0);

-- --------------------------------------------------------

--
-- Structure de la table `traiteur_services`
--

DROP TABLE IF EXISTS `traiteur_services`;
CREATE TABLE IF NOT EXISTS `traiteur_services` (
  `traiteur_id` int NOT NULL,
  `service_id` int NOT NULL,
  PRIMARY KEY (`traiteur_id`,`service_id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `traiteur_services`
--

INSERT INTO `traiteur_services` (`traiteur_id`, `service_id`) VALUES
(2, 1),
(2, 2),
(2, 4),
(2, 6),
(2, 7);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','traiteur','client') NOT NULL,
  `status` enum('actif','inactif','bloque') DEFAULT 'actif',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `email`, `password_hash`, `role`, `status`, `created_at`) VALUES
(1, 'admin@bukavu.com', 'Tino123', 'admin', 'actif', '2026-07-09 10:11:59'),
(2, 'crispin@gmail.com', '$2y$10$9eNhj8smuFFQhjtAfuiy8eyDULLk9XaQ4CLfK2sTFuIUFB4n1A6ba', 'traiteur', 'actif', '2026-07-09 20:31:50'),
(3, 'Justine@gmail.com', '$2y$10$cKUwdccJdg1.Lw3xBp.IK.nuDDTwy44anS/OQPjIb5rLIZS2SuAeO', 'client', 'actif', '2026-07-10 05:21:06'),
(4, 'Mwangaza@gmail.com', '$2y$10$ketFGYFRtRs2yvhKMw.rHe.ANZbAofVwt39lbwf3PHbAnzhjWDUA.', 'traiteur', 'actif', '2026-07-10 11:10:23'),
(5, 'Just@gmail.com', '$2y$10$XuV3pBjtWS.eksmRgdRrSO20Cx5YQS31gYnEkbjwVt2jpKYnMlglS', 'client', 'actif', '2026-07-13 13:10:42');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `admin_profiles`
--
ALTER TABLE `admin_profiles`
  ADD CONSTRAINT `admin_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `client_profiles`
--
ALTER TABLE `client_profiles`
  ADD CONSTRAINT `client_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client_profiles` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`traiteur_id`) REFERENCES `traiteur_profiles` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`service_type_id`) REFERENCES `service_types` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`traiteur_id`) REFERENCES `traiteur_profiles` (`user_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `post_likes`
--
ALTER TABLE `post_likes`
  ADD CONSTRAINT `post_likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_likes_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `client_profiles` (`user_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client_profiles` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_ibfk_2` FOREIGN KEY (`traiteur_id`) REFERENCES `traiteur_profiles` (`user_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `client_profiles` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`traiteur_id`) REFERENCES `traiteur_profiles` (`user_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `temp_codes`
--
ALTER TABLE `temp_codes`
  ADD CONSTRAINT `temp_codes_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `traiteur_profiles`
--
ALTER TABLE `traiteur_profiles`
  ADD CONSTRAINT `traiteur_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `traiteur_services`
--
ALTER TABLE `traiteur_services`
  ADD CONSTRAINT `traiteur_services_ibfk_1` FOREIGN KEY (`traiteur_id`) REFERENCES `traiteur_profiles` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `traiteur_services_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `service_types` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
