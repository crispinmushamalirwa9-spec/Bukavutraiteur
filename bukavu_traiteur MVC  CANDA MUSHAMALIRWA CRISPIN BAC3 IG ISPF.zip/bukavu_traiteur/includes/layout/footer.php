<?php
// /includes/layouts/footer.php
?>
    </main>
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h3><i class="fas fa-utensils"></i> <?= SITE_NAME ?></h3>
                    <p><?= SITE_DESCRIPTION ?></p>
                    <p><i class="fas fa-map-marker-alt"></i> Bukavu, RDC</p>
                </div>
                <div class="footer-col">
                    <h4>Liens rapides</h4>
                    <ul>
                        <li><a href="<?= SITE_URL ?>">Accueil</a></li>
                        <li><a href="<?= SITE_URL ?>client/browse_posts.php">Explorer</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contact</h4>
                    <p><i class="fas fa-envelope"></i> contact@bukavutraiteur.com</p>
                    <p><i class="fas fa-phone"></i> +243 82 000 0000</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?> - Tous droits réservés.</p>
            </div>
        </div>
    </footer>
    <script src="<?= SITE_URL ?>assets/js/script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const flash = document.querySelector('.flash-message');
            if (flash) {
                setTimeout(() => {
                    flash.style.transition = 'opacity 0.5s';
                    flash.style.opacity = '0';
                    setTimeout(() => flash.remove(), 500);
                }, 5000);
            }
        });
    </script>
</body>
</html>