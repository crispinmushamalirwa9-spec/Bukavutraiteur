<?php
// /includes/layouts/header.php
// ATTENTION : Ce fichier est inclus APRÈS config.php,
// donc $pdo, $_SESSION et les fonctions sont disponibles.

// On détermine le titre dynamique de la page
$page_title = $page_title ?? SITE_NAME;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($page_title) ?> - <?= SITE_NAME ?></title>
    <meta name="description" content="<?= SITE_DESCRIPTION ?>">
    <link rel="stylesheet" href="<?= SITE_URL ?>assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <a href="<?= SITE_URL ?>">
                    <i class="fas fa-utensils"></i> <?= SITE_NAME ?>
                </a>
            </div>
            <nav>
                <ul class="nav-menu">
                    <li><a href="<?= SITE_URL ?>">Accueil</a></li>
                    <li><a href="<?= SITE_URL ?>client/browse_posts.php">Explorer</a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <?php if ($_SESSION['user_role'] === 'admin'): ?>
                            <li><a href="<?= SITE_URL ?>admin/dashboard.php">Dashboard Admin</a></li>
                            <li><a href="<?= SITE_URL ?>admin/logout.php">Déconnexion</a></li>
                        <?php elseif ($_SESSION['user_role'] === 'traiteur'): ?>
                            <li><a href="<?= SITE_URL ?>traiteur/dashboard.php">Dashboard</a></li>
                            <li><a href="<?= SITE_URL ?>traiteur/logout.php">Déconnexion</a></li>
                        <?php elseif ($_SESSION['user_role'] === 'client'): ?>
                            <li><a href="<?= SITE_URL ?>client/dashboard.php">Dashboard</a></li>
                            <li><a href="<?= SITE_URL ?>client/logout.php">Déconnexion</a></li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li><a href="<?= SITE_URL ?>client/login.php">Client</a></li>
                        <li><a href="<?= SITE_URL ?>traiteur/login.php">Traiteur</a></li>
                        <li><a href="<?= SITE_URL ?>admin/login.php">Admin</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <div class="user-info">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <span class="user-name">
                        <i class="fas fa-user-circle"></i>
                        <?php 
                            if ($_SESSION['user_role'] === 'traiteur') {
                                $stmt = $pdo->prepare("SELECT service_name FROM traiteur_profiles WHERE user_id = ?");
                                $stmt->execute([$_SESSION['user_id']]);
                                $name = $stmt->fetchColumn();
                                echo e($name ?: 'Traiteur');
                            } elseif ($_SESSION['user_role'] === 'client') {
                                $stmt = $pdo->prepare("SELECT full_name FROM client_profiles WHERE user_id = ?");
                                $stmt->execute([$_SESSION['user_id']]);
                                echo e($stmt->fetchColumn() ?: 'Client');
                            } else {
                                echo 'Admin';
                            }
                        ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <main>
        <?php display_flash_message(); ?>