<?php
// /includes/functions.php

// Sécurité : empêcher un accès direct
if (!defined('ROOT_PATH')) {
    die('Accès direct interdit.');
}

// ------------------------------------------------------------
// 1. GESTION DES UPLOADS
// ------------------------------------------------------------
function upload_file($file, $target_dir, $max_size = MAX_FILE_SIZE) {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'Erreur lors du téléchargement.'];
    }
    if ($file['size'] > $max_size) {
        return ['success' => false, 'message' => 'Fichier trop volumineux (max 10 Mo).'];
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    $allowed_types = array_merge(ALLOWED_IMAGE_TYPES, ALLOWED_VIDEO_TYPES);
    if (!in_array($mime_type, $allowed_types)) {
        return ['success' => false, 'message' => 'Type de fichier non autorisé.'];
    }
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $new_filename = uniqid() . '.' . $extension;
    $destination = $target_dir . $new_filename;
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return ['success' => true, 'filename' => $new_filename];
    } else {
        return ['success' => false, 'message' => 'Erreur lors de l\'enregistrement.'];
    }
}

// ------------------------------------------------------------
// 2. FONCTIONS D'AFFICHAGE DES MÉDIAS
// ------------------------------------------------------------
function media_exists($filename, $type = 'posts') {
    if (empty($filename)) return false;
    $base_path = ($type === 'profile') ? PROFILE_PICS_PATH : POSTS_PATH;
    $file_path = $base_path . $filename;
    return file_exists($file_path) && is_file($file_path);
}

function get_media_url($filename, $type = 'posts', $default = null) {
    if (empty($filename) || !media_exists($filename, $type)) {
        if ($default !== null) return $default;
        return ($type === 'profile') 
            ? SITE_URL . 'assets/uploads/profiles/default_traiteur.jpg'
            : SITE_URL . 'assets/uploads/posts/default_post.jpg';
    }
    $base_url = ($type === 'profile') ? PROFILE_PICS_URL : POSTS_URL;
    return $base_url . $filename;
}

function render_media($filename, $type = 'posts', $class = 'media', $controls = true) {
    if (empty($filename) || !media_exists($filename, $type)) {
        echo '<div class="media-placeholder"><i class="fas fa-file-image"></i> Média indisponible</div>';
        return;
    }
    $url = get_media_url($filename, $type);
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $is_video = in_array($ext, ['mp4', 'webm', 'avi', 'mov', 'mkv']);
    if ($is_video) {
        $controls_attr = $controls ? 'controls' : '';
        echo '<video src="' . $url . '" class="' . $class . '" ' . $controls_attr . '></video>';
    } else {
        echo '<img src="' . $url . '" class="' . $class . '" alt="Média">';
    }
}

// ------------------------------------------------------------
// 3. NOTIFICATIONS
// ------------------------------------------------------------
function add_notification($pdo, $user_id, $message) {
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
    return $stmt->execute([$user_id, $message]);
}
function get_notifications($pdo, $user_id, $limit = 10) {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
    $stmt->execute([$user_id, $limit]);
    return $stmt->fetchAll();
}
function mark_notifications_as_read($pdo, $user_id) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    return $stmt->execute([$user_id]);
}
function count_unread_notifications($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn();
}

// ------------------------------------------------------------
// 4. CLASSEMENT (RANKING) avec bonus pour commandes terminées
// ------------------------------------------------------------
function update_all_rankings($pdo) {
    $sql = "UPDATE traiteur_profiles tp
            SET ranking_score = (
                -- Points pour les likes (chaque like = 2 pts)
                (SELECT COALESCE(SUM(p.likes_count), 0) * 2 FROM posts p WHERE p.traiteur_id = tp.user_id)
                -- Points pour les publications (chaque post = 1.5 pt)
                + (SELECT COALESCE(COUNT(*), 0) * 1.5 FROM posts p WHERE p.traiteur_id = tp.user_id)
                -- Points pour les avis positifs (chaque positif = 3 pts)
                + (SELECT COALESCE(COUNT(*), 0) * 3 FROM reviews r WHERE r.traiteur_id = tp.user_id AND r.rating = 'positif')
                -- Pénalité pour les avis négatifs (chaque négatif = -5 pts)
                - (SELECT COALESCE(COUNT(*), 0) * 5 FROM reviews r WHERE r.traiteur_id = tp.user_id AND r.rating = 'negatif')
                -- Bonus pour les commandes terminées (chaque commande = 2 pts)
                + (SELECT COALESCE(COUNT(*), 0) * 2 FROM orders o WHERE o.traiteur_id = tp.user_id AND o.status = 'termine')
            )
            WHERE tp.user_id IN (SELECT id FROM users WHERE role = 'traiteur' AND status = 'actif')";
    return $pdo->exec($sql);
}

function get_top_traiteurs($pdo, $limit = 10) {
    $stmt = $pdo->query("
        SELECT tp.user_id, tp.service_name, tp.profile_pic, tp.ranking_score, tp.address,
               (SELECT COUNT(*) FROM orders o WHERE o.traiteur_id = tp.user_id AND o.status = 'termine') as total_orders_done
        FROM traiteur_profiles tp
        JOIN users u ON tp.user_id = u.id
        WHERE u.status = 'actif'
        ORDER BY tp.ranking_score DESC
        LIMIT $limit
    ");
    return $stmt->fetchAll();
}

// ------------------------------------------------------------
// 5. STATISTIQUES ADMIN
// ------------------------------------------------------------
function get_admin_stats($pdo) {
    $stats = [];
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'traiteur' AND status = 'actif'");
    $stats['total_traiteurs'] = $stmt->fetchColumn();
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'client' AND status = 'actif'");
    $stats['total_clients'] = $stmt->fetchColumn();
    $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM orders GROUP BY status");
    $stats['orders_by_status'] = $stmt->fetchAll();
    $stmt = $pdo->query("
        SELECT tp.user_id, tp.service_name, COUNT(o.id) as total_orders
        FROM traiteur_profiles tp
        JOIN orders o ON tp.user_id = o.traiteur_id
        GROUP BY tp.user_id
        ORDER BY total_orders DESC
        LIMIT 5
    ");
    $stats['top_traiteurs'] = $stmt->fetchAll();
    $stmt = $pdo->query("
        SELECT tp.user_id, tp.service_name, COUNT(o.id) as total_orders
        FROM traiteur_profiles tp
        LEFT JOIN orders o ON tp.user_id = o.traiteur_id
        GROUP BY tp.user_id
        ORDER BY total_orders ASC
        LIMIT 5
    ");
    $stats['bottom_traiteurs'] = $stmt->fetchAll();
    return $stats;
}

// ------------------------------------------------------------
// 6. SUPPRESSION AUTO DES CLIENTS SIGNALÉS
// ------------------------------------------------------------
function auto_delete_reported_clients($pdo) {
    $sql = "SELECT client_id, COUNT(DISTINCT traiteur_id) as nb_reports 
            FROM reports 
            GROUP BY client_id 
            HAVING nb_reports >= :limit";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['limit' => REPORT_LIMIT_BEFORE_DELETE]);
    $clients_to_delete = $stmt->fetchAll();
    $deleted_count = 0;
    foreach ($clients_to_delete as $client) {
        $delete = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'client'");
        $deleted = $delete->execute([$client['client_id']]);
        if ($deleted) {
            $deleted_count++;
            add_notification($pdo, 1, "Client ID {$client['client_id']} supprimé (2 signalements).");
        }
    }
    return $deleted_count;
}

// ------------------------------------------------------------
// 7. GÉNÉRATION CODE 5 CHIFFRES
// ------------------------------------------------------------
function generate_traiteur_code($pdo, $admin_id) {
    do {
        $code = str_pad(random_int(0, 99999), 5, '0', STR_PAD_LEFT);
        $check = $pdo->prepare("SELECT id FROM temp_codes WHERE code = ?");
        $check->execute([$code]);
    } while ($check->rowCount() > 0);
    $insert = $pdo->prepare("INSERT INTO temp_codes (code, created_by) VALUES (?, ?)");
    $insert->execute([$code, $admin_id]);
    return $code;
}

// ------------------------------------------------------------
// 8. FILTRER LES TRAITEURS PAR SERVICE
// ------------------------------------------------------------
function get_traiteurs_by_service($pdo, $service_id) {
    $stmt = $pdo->prepare("
        SELECT tp.user_id, tp.service_name, tp.profile_pic, tp.ranking_score, tp.address
        FROM traiteur_profiles tp
        JOIN traiteur_services ts ON tp.user_id = ts.traiteur_id
        JOIN users u ON tp.user_id = u.id
        WHERE ts.service_id = ? AND u.status = 'actif'
        ORDER BY tp.ranking_score DESC
    ");
    $stmt->execute([$service_id]);
    return $stmt->fetchAll();
}

// ------------------------------------------------------------
// 9. STATISTIQUES D'UN TRAITEUR (commandes par statut)
// ------------------------------------------------------------
function get_traiteur_order_stats($pdo, $traiteur_id) {
    $stats = [];
    $statuses = ['en_attente', 'en_cours', 'termine', 'refuse'];
    foreach ($statuses as $status) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE traiteur_id = ? AND status = ?");
        $stmt->execute([$traiteur_id, $status]);
        $stats[$status] = $stmt->fetchColumn();
    }
    return $stats;
}

// ------------------------------------------------------------
// 10. TYPES DE SERVICES
// ------------------------------------------------------------
function get_all_service_types($pdo) {
    $stmt = $pdo->query("SELECT * FROM service_types ORDER BY name ASC");
    return $stmt->fetchAll();
}
?>