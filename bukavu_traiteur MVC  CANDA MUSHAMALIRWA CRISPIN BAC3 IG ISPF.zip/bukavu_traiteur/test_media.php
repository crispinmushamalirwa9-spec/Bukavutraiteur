<?php
require_once __DIR__ . '/config/config.php';

echo "<h1>Diagnostic des médias</h1>";

// Vérifier les constantes
echo "<h2>Constantes</h2>";
echo "ROOT_PATH = " . ROOT_PATH . "<br>";
echo "SITE_URL = " . SITE_URL . "<br>";
echo "POSTS_PATH = " . POSTS_PATH . "<br>";
echo "POSTS_URL = " . POSTS_URL . "<br>";
echo "PROFILE_PICS_PATH = " . PROFILE_PICS_PATH . "<br>";
echo "PROFILE_PICS_URL = " . PROFILE_PICS_URL . "<br>";

// Lister les fichiers dans le dossier posts
echo "<h2>Fichiers dans assets/uploads/posts/</h2>";
$files = glob(POSTS_PATH . "*");
if (empty($files)) {
    echo "Aucun fichier trouvé dans le dossier posts.<br>";
} else {
    foreach ($files as $file) {
        $filename = basename($file);
        $url = POSTS_URL . $filename;
        echo "Fichier : $filename<br>";
        echo "Chemin absolu : $file<br>";
        echo "URL publique : $url<br>";
        if (file_exists($file)) {
            echo "✅ Le fichier existe sur le serveur.<br>";
        } else {
            echo "❌ Le fichier n'existe PAS sur le serveur.<br>";
        }
        echo "<img src='$url' style='max-width:200px;'><br><hr>";
    }
}

// Lister les fichiers dans profiles
echo "<h2>Fichiers dans assets/uploads/profiles/</h2>";
$files2 = glob(PROFILE_PICS_PATH . "*");
if (empty($files2)) {
    echo "Aucun fichier trouvé dans le dossier profiles.<br>";
} else {
    foreach ($files2 as $file) {
        $filename = basename($file);
        $url = PROFILE_PICS_URL . $filename;
        echo "Fichier : $filename<br>";
        echo "URL publique : $url<br>";
        echo "<img src='$url' style='max-width:200px;'><br><hr>";
    }
}
?>